function [alphaSt,nf,ng,success] = ...
 zoomWolfe(alphaL,alphaR,f,xc,val_fc,d,dd,val_fL,val_fR,slope,c1,c2,success)

%
% Auxiliary function for the line search 
% satisfying the strong Wolfe conditions, based on 
% Algorithms 3.5 (LS) and 3.6 (zoom) of Nocedal & Wright (2ed),
% together with elements from A6.3.1(mod) from Dennis & Schnabel.
%
% The interval [alpha_L,alpha_R] brackets acceptable steplengths
% verifying the strong Wolfe condition. The left extreme verifies the
% Armijo condition, and the directional derivative at this point along
% the search direction (d) is provided in 'slope'. Besides the function 
% handle 'f', and the information at the current iterate 
% (xc, val_fc, d, dd), we also provide the function values at the 
% extreme points of the interval(val_fL, val_fR). The flag 'success'
% is self explanatory, c1  and c2 are the constants of the Armijo and
% the curvature conditions, respectively.
%
% Coded by S. A. Santos for the experiments of the manuscript
% A structured diagonal Hessian approximation method with 
% evaluation complexity analysis for nonlinear least squares,
% joint work with H. Mohammad
%
% The code was modified by Mahmoud M. Yahaya for CG algorthms
% Last update: 11/Nov/2022
%

% initialize output to prevent error message
alphaSt=NaN; 
nf = 0; 
ng = 0;

MinIntervalSize=1e-8;

while ( abs(alphaR-alphaL) > MinIntervalSize && ~success )
    % quadratic interpolation for computing trial step
    alphaDif = alphaR - alphaL;
    alphaInc = - slope*alphaDif^2/(2*(val_fR-val_fL-slope*alphaDif));
    % 
    alpha1 = alphaL + min(max(0.2*alphaDif, alphaInc),0.99*alphaDif);
    % new trial point
    xt = xc + alpha1* d;
    [val_ft,~,~]=feval(f, xt, [1 0 0]);
    nf=nf+1;
    
   %  disp([alphaL,    alpha1,    alphaR])
   %  pause
    
    if ( val_ft > val_fc + c1*alpha1*dd )
        % as the trial point does not verify the Armijo condition, 
        % keeps bracketing on the right
        alphaR=alpha1;
        val_fR=val_ft;
    else
       % Since alpha1 verifies Armijo, check if it also fulfills
       % the curvature condition.
        [~,gt,~]=feval(f, xt, [0 1 0]);
        ng = ng+1;
        gtd=gt'*d;     
        if (abs(gtd) <= -c2*dd)
            alphaSt = alpha1; success=true;
        else
            if gtd < 0
                % keeps bracketing on the left
                alphaL = alpha1;
                val_fL=val_ft;
                slope = gtd;
            else
                % keeps bracketing on the right
                alphaR = alpha1; 
                val_fR = val_ft;
            end
        end
    end
end

end