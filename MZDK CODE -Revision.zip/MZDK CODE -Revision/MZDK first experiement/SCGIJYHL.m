function SCGIJYHL(probnum,dimnum,xlrange)
% Two diagonal conjugate gradient methods for unconstrained optimization
% H. Mohammad, and I. M. Sulaiman (2022)
% dprp Algorithm
% Input:  dimnum= dimension
%         fnum= function number
%        xnum= initial iterate number
%        tol= stoping tolarance
%        maxit= maximum nuber of iteration
%clear t;
tic

if nargin<3
    xlrange='[]';
end
if nargin<2
    dimnum=1; %default dimension number
end
if nargin<1
    probnum=1; % default initial point
end
if nargin<1
    probnum=1; %default problem number
end

%%%%%%%%%%%%%%%% defining problems%%%%%%%%%%%%%%%%%%%%%%%%%%%
problem=probnum;
switch problem
    case 1%4
        f='ExtPSC1';
    case 2%13
        f='Diagonal5';
    case 3%14
        f='Diagonal6';
    case 4%20
        f= 'Raydan2';
    case 5%21
        f='ExtTridiag2';
    case 6%22
        f='PertQuad';
    case 7%24
        f='ExtHimmelblau';
    case 8%29
        f='ExtBD1';
    case 9%31
        f='QUARTC';
    case 10%35
        f='LIARWHD';
    case 11%44
        f='PartPertQuad';
    case 12%50
        f='ExtTET';
    otherwise
        f='problem';
end

%%%%%%%%%%%%%%%%% defining dimension%%%%%%%%%%%%%%%%%%%%%%%%%%
switch dimnum
    case 1
        dim=5000;
    case 2
        dim=50000;
    case 3
        dim=100000;
    otherwise
        dim=dimnum;    % for any other dimension not listed    
end
%%%%%%%%%%%%%%%%%% defining initial points%%%%%%%%%%%%%%%%%%%%%%%

initguess = probnum;
switch initguess
    case 1%4
        x0=repArray(dim,3,0.1)';
    case 2%13
        x0=oneNumber(1.1,dim)';
    case 3%14
        x0=oneNumber(1,dim)';
    case 4%20
        x0=oneNumber(1,dim)';
    case 5%21
        x0=oneNumber(1,dim)';
    case 6%22
        x0=oneNumber(0.5,dim)';
    case 7%24
        x0=oneNumber(1,dim)';
    case 8%29
        x0=oneNumber(0.1,dim)';
    case 9%31
        x0=oneNumber(2,dim)';
    case 10%35
        x0=oneNumber(4,dim)';
    case 11%44
        x0=oneNumber(0.5,dim)';
    case 12%50
        x0=oneNumber(0.1,dim)';
    otherwise
        x0=probnum; % for other problems
end


%%%%%%%%%%%%%%%%%% defining initial points%%%%%%%%%%%%%%%%%%%%%%%
% maximum inner iterations for the line search
Maxitc = 5000; maxit=5000;  % default maximum iterations for outer loop and inner loop resp.
tol=1e-6; % default tolarance
% initialization of the least possible value of alpha, memory "N" and etak
minalpha = 1e-3; eta_const = 0.01;
%  initialize the iteration counter and assigning up the initial point,
%  "x0"
itc=0; xc=x0; 
% for the line search 
c1=0.01; c2=0.1;
%c1=0.9; c2=0.1; %sigma1=c1, sigma2=c2
% first step length
alpha=1; %initial alpha
% function and gradient call
[val_fc,gc,~]=feval(f, xc, [1 1 0]);
numf=1;  numg=1;
inittry = 1;  kappa = 1e-4;
normg=norm(gc,inf);
% initial spectral parameter
dc=-gc; % initial direction
while(normg > tol && itc < Maxitc)
% while(normg > tol * ( 1 + abs(val_fc)) ) && ( itc < Maxitc)  
 %%     Line search procedure
    dd=gc'*dc;
    % initial step length as Nocedal & Wright 2ed. p.59
    if itc > 0
        alpha=alpha*(g0'*d0)/dd;
        %alpha=min(1,1.01*alpha);
    end
    [alpha, nfe] = STWolfe1Upd(f,xc,dc,c1,c2);
    numf = numf+nfe;
 %%    % update the iterate and compute necessary info at the new point
    xt = xc + alpha*dc;
    s  = xt - xc;
    [val_ft, gt, ~] = feval(f, xt, [1 1 0]); %gradient Jk^TFk
    numg=numg+1; numf=numf+1;
    y = gt - gc;
    
    
    %betakN =  ((y'*gt)/(numk) - (2*(gt'*dc)*norm(y)^2/numk^2)
 %% computing the search direction  
    tk1=abs(gt'*dc)/norm(dc)*norm(gt);
    tk2=(norm(gt)/norm(dc))*(abs(gt'*dc));
    tk3=max(gc'*(gc-dc), 2*norm(gc)^2);
    beta1=2*(norm(gt)^2-tk1*tk2)/tk3;
    
    beta2 =0.04*(gt'*dc)/(norm(dc)^2); 
    

          
    
    if  (-0.9)*(norm(gc)^2) <= (gc'*dc) && (gc'*dc) <= (0.4*norm(gc)^2)
        dt = -gt + beta1*dc;
    else
        dt = -gt + beta2*dc;
    end
    

% ------------------not useful-----------------------------------------
%     alpha0 = alpha*abs(s'*dt)/norm(dt);
%     normt = gt'*dt;
%     alpha0 = alpha*(dd/normt);  % Norcedal pp 58 Option I
%     alpha0 = (val_ft - val_fc)/normt; % Norcedal pp 58 Option II
% ---------------------------------------------------------------------
    xc=xt;
    dc=dt;
    gc=gt;  
    val_fc=val_ft;
    d0=dc;
    g0=gc;
    normg=norm(gc,inf);
    itc=itc+1;
end
toc
%  disp(xt)
    disp(['itc'     '/'     'numf'     '/'     'numg'     '/'      'toc'    '/'    'normg'     '/'     'val_fc'])
    disp([num2str(itc) ' / ' num2str(numf) ' / ' num2str(numg)   ' / '  num2str(toc)  ' / ' num2str(normg)  ' / '  num2str(val_fc)])
    if dimnum == [1 2 3 4 5]
        disp(num2str(dim))
    else
        disp(num2str(length(xc)))
    end
   disp(f)
  table2='ClassFirstExp_.xls';
  T={num2str(itc),num2str(numf),num2str(numg),num2str(toc),num2str(val_fc)};
 % %T={num2str(l),num2str(u)};
  sheet=3;
  xlRange=xlrange;
  xlswrite(table2,T,sheet,xlRange);
end
  
  % point_generators
function sp = oneNumber(number, dimension)
% returns number repeted dimesion times
sp = repmat(number, 1, dimension);
end


function sp = aToB(a, b)
% return integers between a and b
sp = linspace(a, b, b - a + 1);
end


function sp = expArray(dimension, exp)
% returns n^exp array with dimension elements
sp = zeros(1, dimension);
for i=1:dimension
    sp(i) = round(i^exp, 5, 'significant');
end
end


function sp = repArray(dimension, varargin)
% returns array with repeted provided elements of lentght dimension
% if no elements are provided returns zeros(1, dimension)
if nargin > 0
    aux = cell2mat(varargin);
    sp = repmat(aux, 1, round(dimension / length(aux)) + 1);
    sp = sp(1:dimension);
else
    sp = zeros(1, dimension);
end
end
 % %winopen(table2)