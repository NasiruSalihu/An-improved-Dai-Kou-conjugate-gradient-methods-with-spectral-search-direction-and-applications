function SCGHZ(probnum,dimnum,xlrange)
% Two diagonal conjugate gradient methods for unconstrained optimization
% H. Mohammad, and I. M. Sulaiman (2022)
% dprp Algorithm
% Input:  dimnum= dimension
%         fnum= function number
%        xnum= initial iterate number
%        tol= stoping tolarance
%        maxit= maximum nuber of iteration
%clear t;
tic

if nargin<3
    xlrange='[]';
end
if nargin<2
    dimnum=1; %default dimension number
end
if nargin<1
    probnum=1; % default initial point
end
if nargin<1
    probnum=1; %default problem number
end

%%%%%%%%%%%%%%%% defining problems%%%%%%%%%%%%%%%%%%%%%%%%%%%
problem=probnum;
switch problem
    case 1%4
        f='ExtPSC1';
    case 2%13
        f='Diagonal5';
    case 3%14
        f='Diagonal6';
    case 4%20
        f= 'Raydan2';
    case 5%21
        f='ExtTridiag2';
    case 6%22
        f='PertQuad';
    case 7%24
        f='ExtHimmelblau';
    case 8%29
        f='ExtBD1';
    case 9%31
        f='QUARTC';
    case 10%35
        f='LIARWHD';
    case 11%44
        f='PartPertQuad';
    case 12%50
        f='ExtTET';
    otherwise
        f='problem';
end

%%%%%%%%%%%%%%%%% defining dimension%%%%%%%%%%%%%%%%%%%%%%%%%%
switch dimnum
    case 1
        dim=5000;
    case 2
        dim=50000;
    case 3
        dim=100000;
    otherwise
        dim=dimnum;    % for any other dimension not listed    
end
%%%%%%%%%%%%%%%%%% defining initial points%%%%%%%%%%%%%%%%%%%%%%%

initguess = probnum;
switch initguess
    case 1%4
        x0=repArray(dim,3,0.1)';
    case 2%13
        x0=oneNumber(1.1,dim)';
    case 3%14
        x0=oneNumber(1,dim)';
    case 4%20
        x0=oneNumber(1,dim)';
    case 5%21
        x0=oneNumber(1,dim)';
    case 6%22
        x0=oneNumber(0.5,dim)';
    case 7%24
        x0=oneNumber(1,dim)';
    case 8%29
        x0=oneNumber(0.1,dim)';
    case 9%31
        x0=oneNumber(2,dim)';
    case 10%35
        x0=oneNumber(4,dim)';
    case 11%44
        x0=oneNumber(0.5,dim)';
    case 12%50
        x0=oneNumber(0.1,dim)';
    otherwise
        x0=probnum; % for other problems
end



%[f,g,~]=feval(f, x0, [1 1 0]);

[~, g, ~] = feval(f, x0, [0 1 0]);
%[g,~]=feval(p,x0);
%numg=numg+1; numf=numf+1;
norm_g=norm(g);
%[~,f]=feval(p,x0);
%f=sum(f);
nf=1; 
ng=1;
d=-g; %slope0=g'*d; 
%a1=0.5;
k=0;
x=x0;
c1 = .001; c2 = 0.1;
%c1=0.9; c2=0.1;
%tt=0.5;
%iota=10^30;
format long e
while (norm_g>.000001) && (k<2000)
    [Alpha,nfe] = St_Wolfe1m(f,x,d,c1,c2);
    t=g; x0=x;
    x=x+Alpha*d;
    %g=feval(f,x,1);
    %f=feval(f,x,0);
    [~, g, ~] = feval(f, x0, [0 1 0]);
    %[g,~]=feval(p,x);
    norm_g=norm(g);
    nf=nf+1;
    ng=ng+1;
    s=x-x0;
    y=g-t;
    %y = gt - gc;
    eta_const = 0.01;    
    etak = -1 / (norm(d) * min(eta_const, norm(t)));

    %etak = -1/(norm(d)*min(eta_const, norm(t) ));
    numk  = (d'*y);
    betakN =  ((y'*g)/(numk) - (2*(g'*d)*norm(y)^2/numk^2));
    barbetakN = max(betakN, etak);
    dk = -g + barbetakN*d; 
    kappa = 1e-4; 
    if (g'*dk) >= -kappa*norm(g)*norm(dk)
        d = -g;
    end    
    nf=nfe+nf;
    k=k+1;
    
end

% disp([num2str(k) ' / ' num2str(nf) ' / '  num2str(ng) ' / ' num2str(toc)  ' / ' num2str(norm(g)) ])
% disp([num2str(p)])
% %disp([num2str(xx(1))])
%   table1='wolfeexp.xlsx';
%   T={num2str(k),num2str(nf),num2str(toc),num2str(norm(g))};
%   sheet=1;
%   xlRange=xlrange;
%   xlswrite(table1,T,sheet,xlRange);


 disp(['itc'     '/'     'numf'     '/'     'numg'     '/'      'toc'    '/'    'normg'     ])
    disp([num2str(k) ' / ' num2str(nf) ' / ' num2str(ng)   ' / '  num2str(toc)  ' / ' num2str(norm(g))])
    if dimnum == [1 2 3 4 5]
        disp(num2str(dim))
    else
        disp(num2str(length(x0)))
    end
   disp(f)
  table2='ClassFirstExp_.xls';
  T={num2str(k),num2str(nf),num2str(ng),num2str(toc)};
 % %T={num2str(l),num2str(u)};
  sheet=3;
  xlRange=xlrange;
  xlswrite(table2,T,sheet,xlRange);


toc;

% point_generators
function sp = oneNumber(number, dimension)
% returns number repeted dimesion times
sp = repmat(number, 1, dimension);
end


function sp = aToB(a, b)
% return integers between a and b
sp = linspace(a, b, b - a + 1);
end


function sp = expArray(dimension, exp)
% returns n^exp array with dimension elements
sp = zeros(1, dimension);
for i=1:dimension
    sp(i) = round(i^exp, 5, 'significant');
end
end


function sp = repArray(dimension, varargin)
% returns array with repeted provided elements of lentght dimension
% if no elements are provided returns zeros(1, dimension)
if nargin > 0
    aux = cell2mat(varargin);
    sp = repmat(aux, 1, round(dimension / length(aux)) + 1);
    sp = sp(1:dimension);
else
    sp = zeros(1, dimension);
end
end
end