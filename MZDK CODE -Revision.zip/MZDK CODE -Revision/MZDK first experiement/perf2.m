function[C] =perf2(T,metric)
%PERF  Performace profiles
%
%T=xlsread('shmsy12.xlsx')
%[C]=perf(T,2)
% PERF(T,logplot)-- produces a performace profile as described in
%   Benchmarking optimization software with performance profiles,
%   E.D. Dolan and J.J. More', 
%   Mathematical Programming, 91 (2002), 201--213.
% Each column of the matrix T defines the performance data for a solver.
% Failures on a given problem are represented by a NaN.
% The optional argument logplot is used to produce a 
% log (base 2) performance plot.
%
% This function is based on the perl script of Liz Dolan.
%
% Jorge J. More', June 2004

colors  = ['r' 'b' 'g' 'k' 'c' 'm' 'y' 'p'];
lines   = [':' '-' '-.' '--'];
markers = ['x' '*' 's' 'd' 'v' '^' 'o'];

[np,ns] = size(T);

% Minimal performance per solver

minperf = min(T,[],2);

% Compute ratios and divide by smallest element in each row.

r = zeros(np,ns);
for p = 1: np
  r(p,:) = T(p,:)/minperf(p);
end

%find the number of appearence of 1 where is the matix after get min
A=sum(r==1);
np
%find number of fails
B=sum(isnan(r));

%determine which column has less number of fail
[~,col]=min(sum(isnan(r)));

%calculate the percentage of failure
P=(np-B)/np;

% calculate the percentage of better
T=(A/np);

r = log2(r);

max_ratio = max(max(r));

%divide each row with total number of the data np
%y=[1:np]'
%d = ones(np,ns)*y
%u=y*d
%for p = 1: np
    %d(p,:) = y(p,:)/np;
%end

% Replace all NaN's with twice the max_ratio and sort.

r(isnan(r)) = 2*max_ratio;
r = sort(r);

% Plot stair graphs with markers.

clf;
for s = 1: ns
 [xs,ys] = stairs(r(:,s),[1:np]/np);
 option = ['-' colors(s) markers(s)];
 %plot(xs,ys,option,'MarkerSize',3);
 plot(xs,ys,option,'MarkerSize',3,'LineWidth',2);
 hold on;
end

% Axis properties are set so that failures are not shown,
% but with the max_ratio data points shown. This highlights
% the "flatline" effect.

axis([ 0 1.1*max_ratio 0 1 ]);
legend('','HYB','LSCD','LSDY','LSFR','NSLS','NSCD',6); %here you named your method according to the table in the excel sheet and put the numer of the column
%ttl = sprintf('Performance profile: %s',metric);
%title(ttl);
ylabel('T_s(t)');
xlabel('t');
C=[A;T;B;P];
%countPercentage=100*hist(r(p,:),B) / numel(r);
%hgexport(gcf, regexprep(metric,'[^\w'']',''), hgexport('factorystyle'), 'Format', 'png');
%to call the function write
%T=xlsread('shmsy12.xlsx');
%perf(T,2)
%where shmsy12.xlsx is the name of the excel file that contains the data
%perf is name of the matlab code of the performance profile with T as input
%data arrange in column and 2 total number of input