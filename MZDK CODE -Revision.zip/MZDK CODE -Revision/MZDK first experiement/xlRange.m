function [ output_args ] = xlRange( columnNum,rowNum )
%xlRange(columnNum,rowNum) will return alpha-numeric excel range
% Scott Williams UTS Sydney 18-Apr-15
%_
% Requirements:
% This function and number2letter.m to be placed in Matlab folder for
% user defined functions.
% number2letter.m is % user defined function is used in execution
%      - available at Mathworks downloads website, enclosed with this file in zip
% Advise to get xlwrite, by Alec De Zegher to use in conjunction with this code:
% http://www.mathworks.com/matlabcentral/fileexchange/38591-xlwrite--generate-xls-x--files-without-excel-on-mac-linux-win
%     -xlswrite has requirements also
%_
%Range=xlRange(1,2)will return alpha-numeric character array 'A2' 
%_
%Limitations: 
% * Will return value -1 if out the range 1<columnNum<702
% * Error checking not exhaustive
% * Written for use with xlwrite, which works up to column 256 (column IV)
% * This function will not work past column 702 (column ZZ) 
%Usage: 
% * For use in xlwrite, the user defined function on Mathworks
% * xlwrite replaces xlswrite which does not work on Mac
% * Good for use with loops with arrays writing to excel document
%     - Use column number of array instead of specifying alpha-numeric range 
% * xlwrite is available at:
% Useful if using with array with 256 or less columns
% Usage examples:
%_
%_Between asterisks copied from xlwrite help:
%******* Following commands entered prior to first xlswrite command execution 
%   * This function requires the POI library to be in your javapath.
%     To add the Apache POI Library execute commands: 
%     (This assumes the POI lib files are in folder 'poi_library')
%       javaaddpath('poi_library/poi-3.8-20120326.jar');
%       javaaddpath('poi_library/poi-ooxml-3.8-20120326.jar');
%       javaaddpath('poi_library/poi-ooxml-schemas-3.8-20120326.jar');
%       javaaddpath('poi_library/xmlbeans-2.3.0.jar');
%       javaaddpath('poi_library/dom4j-1.6.1.jar');
%******
%_Usage examples
%_
%1. xlwrite (user defined function for Mac):
% Typical usage may be;
% To enter 'Range' to xls function , say 'D17'
%Range=xlRange(4,17) returns the character array 'D17'
% _
% to print to an array to desktop with filename 1.xls, starting at D17 on 'Sheet1'
% to check desired filepath, right click the file and get info
% FilePath='/users/username/desktop/1.xls'
% Array=rand(20,3) %generates random array 3 columns wide, 20 rows
% xlwrite(FilePath,Array,'Sheet1',xlRange(4,17))
% Correct syntax for xlwrite to be adhered to.
%_
% should you only want to copy the top part of the variable Array to the same excel file
% use the strcat function for Range:
% say desired range is 'B11:B13' then
% Range2=strcat(xlRange(2,11),':',xlRange(2,13))% returns 'B11:B13'
% xlwrite(FilePath,Array,'Sheet1',Range2)
%2. xlsread
% Range reading does not seem to exist on mac, may work on PC
% Documentation indicates it should.
% to read cell range B11:F36 from the file example
% Range3=strcat(xlRange(2,11),':',xlRange(6,36))% returns 'B11:F36'
%xlsread(FilePath,'Sheet1',Range3)
% _
%I will respond to feedback very slowly. Apologies in advance.
%_

%
    if columnNum>702% column is past ZZ in excel
        output_args='-1';
    else

        let1=fix(columnNum/26);
        if let1==0
           let1='';
        end
        if columnNum==0
          output_args='-1';
          %zero input not allowed
        else %columnNum is divisible by 0

            let2=rem(columnNum,26);

            if let2==0
                %special case for zth term
                let2='Z';
                %redefine let1
                if let1==1%Z column alone
                    output_args=strcat(let2,num2str(rowNum));
                else
                    output_args=strcat(number2letter(let1-1),let2,num2str(rowNum));
                end
            else
                output_args=strcat(number2letter(let1),number2letter(let2),num2str(rowNum));
            end
        end
    
    end