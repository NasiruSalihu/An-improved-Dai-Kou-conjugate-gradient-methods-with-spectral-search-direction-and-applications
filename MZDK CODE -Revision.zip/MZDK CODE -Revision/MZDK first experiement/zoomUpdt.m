function [Alpha, nfee] = zoomUpdt(...
      lo, hi, flo, fhi, glo, ghi, f0, g0, x0, d,p, c1, c2)
% This line-search function is re-created for solving uncontrained problems
% culled from CUTEr library
% modified author: Mahmoud M Yahaya
% last update: 05/01/2023

fail = 0;
lo2 = hi;  
flo2 = fhi;
glo2 = ghi;
nfee = 0;
while lo ~= hi & nfee < 50  
   nfee = nfee + 1;
   bisect = (lo + hi)/2;    
   interp = cubic_interp(lo, lo2, flo, flo2, glo, glo2); 
   if inside(interp, lo, bisect)  
      atry = interp; 
   else
      atry = bisect; 
   end;
   xtry = x0 + atry*d;         
   % [~,ftry]=feval(p,xtry);
   [ftry,~,~]=feval(p,xtry,[1,0,0]);
   % ftry=sum(ftry);   
   % [gradtry,~]=feval(p,xtry);
   [~,gradtry,~]=feval(p,xtry,[0,1,0]);
   gtry = gradtry'*d;          
   if (ftry > f0 + c1*atry*g0 || ftry >= flo)    
      hi = atry; 
      lo2 = hi; flo2 = ftry; glo2 = gtry;  
   else
      if abs(gtry) <= -c2*g0     
         Alpha = atry; x = xtry; f = ftry; grad = gradtry;
         return
      end
      if gtry*(hi - lo) >= 0     
         hi = lo; 
      end
      lo2 = lo; flo2 = flo; glo2 = glo;   
      lo = atry; flo = ftry; glo = gtry;  
   end 
end 
Alpha = atry; x = xtry; f = ftry; grad = gradtry; fail = 1; 