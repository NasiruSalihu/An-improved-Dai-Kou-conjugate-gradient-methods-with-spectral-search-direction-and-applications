function RUNSEXPCG(solverNum, num_prob, num_dim)
% function that perform the runs for conjugate gradient runner experiments
% Written by Mahmoud M. Yahaya:  Nov. 17th 2022; mahmoudpd@gmail.com
% Note this code is for problems with standard initial points
% inputs: num_prob ---- number of problems
%        num_dim ----- number of dimensions
%        solvernum----- The user define number of the solver, corresponding
%        to initial cell number in the excel file


    for i=12:num_prob % start from the first s/n of the small scale for small scale problems
        for j=1:num_dim % for large scale prob. 3 diff. dimension comment it for
            %small scale.
            rowNum=num_dim*(i-1)+j+2; % for large scale problems
            probnum=i;
            %inpointnum=i;
            dimnum=j; % for small and large scale problems
            % num_dim=j; % for small and large scale problems
            xlrange=xlRange(solverNum,rowNum);
                switch solverNum
                    case 3
                      HZMethodNEW(probnum,dimnum,xlrange);                      
                    case 9
                      SCGMF(probnum, dimnum, xlrange);
                    case 16
                      SCGDK(probnum, dimnum, xlrange);
                    case 23
                      SCGZDK(probnum, dimnum, xlrange);
                    case 30
                      SCGMZDK(probnum, dimnum, xlrange);
                    case 37
                      SCGBN(probnum, dimnum, xlrange);
                    case 43
                      SCGTHS(probnum, dimnum, xlrange);
                    case 50
                      SCGDDY(probnum, dimnum, xlrange);  
                    case 56
                      SCGKD(probnum, dimnum, xlrange);
                    case 62
                      SCGSHCG2(probnum, dimnum, xlrange);
                    case 68
                      SCGIJYHL(probnum, dimnum, xlrange);
                    otherwise
                       disp('wrong solver number')
                       break
                end
         end
   end