function [ outVal, outGr, outHes ] = New_func( x0, VGH )

	n = length(x0);
	outVal = 0;
	outGr = 0;
	
	%constants

    if VGH(1) > 0
		outerPart = (x0(1) - 5)^2;
		for i=1:n-1
			outVal = outVal + outerPart + (x0(i) - 1)^2;
		end
    end
	
    if VGH(2) > 0
		outGr = zeros(n,1);
		outGr(1) = 2*(x0(1) - 5);%derivative is the same for both vars
        for i=2:n
			outGr(i) = outGr(i) + 2*(x0(i) - 1);
        end
        
    end
    
%     This Hessian is NOT for this function, therefore its used
    if VGH(3) > 0
		outHes = zeros(n,n);

		for i=1:n
			outHes(i,i) = outHes(i,i) + 2*i;
		end
		outHes(1,1) = outHes(1,1) + (2*n)/c;
		outHes(1,n) = outHes(1,n) + (2*n)/c;
			
		outHes(n,1) = outHes(n,1) + (2*n)/c;
		outHes(n,n) = outHes(n,n) + (2*n)/c;
    else
        outHes = 0;
    end

    
end
