function dpf4fr_excelm(fnum,xlrange)
% Two diagonal conjugate gradient methods for unconstrained optimization
% H. Mohammad, and I. M. Sulaiman (2022)
% dprp Algorithm
% Input:  dimnum= dimension
%         fnum= function number
%        xnum= initial iterate number
%        tol= stoping tolarance
%        maxit= maximum nuber of iteration
clear t;
tic
% last update 3/3/2022
%%%%% default maxit, fev and tol, constant input %%%%%%%%%%%%%%%%%%%%%%%
% if nargin<4
%     maxiter=1000; % default max. iter
% end
% if nargin<3
%     epsilon=1e-6; % default tolarance
% end
% %%%%%%%%%%%%% variable input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% if nargin<2
%     xlrange=[]; % excel range
% end
% if nargin<3
%     xnum=1; % default initial point
% end
% if nargin<2
%     dimnum=1; % default dimension
% end
% if nargin<1
%     fnum=1; % default problem
% end
%%%%%%%%%%%%%%%%%%% defining dimension%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%switch dimnum
%    case 1
%        dim=1000;
        %dim=9;
%    case 2
 %       dim=5000;
        %dim=49;
%    case 3
%        dim=10000;
        %dim=99;
%    case 4
%        dim=50000;
        %dim=199;
%    case 5
%        dim=100000;
        %dim=499;
    %case 6
     %    dim=4;
%     case 7
%         dim=20000;
%     case 8
%         dim=50000;
%     case 9
%         dim=70000;
%     case 10
%         dim=100000;
 %   otherwise
%        dim=dimnum;    % for any other dimension    
%end
%%%%%%%%%%%%%%%%%% defining problems%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
problem=fnum;
switch problem
    case 1
        p='EPenlty';
        dim=100;
        x0=-6*ones(dim,1);
   case 2
        p='EPenlty';
        dim=10000;
        x0=-6*ones(dim,1);
    case 3
        p='EPenlty';
        dim=20000;
        x0=-6*ones(dim,1);
    case 4
        p='Emaratos'; %Over 1000 Iterations
        dim=2;
        x0=21*ones(dim,1);
        %x0=repmat([-1;-1],[(dim/2), 1]);     
    case 5
        p='Emaratos'; %Over 1000 Iterations
        dim=30;
        %x0=repmat([-1;-1],[(dim/2), 1]); 
        x0=21*ones(dim,1);
    case 6
        p='Diag5';
        dim=10;
        x0=1.1*ones(dim,1);
    case 7
        p='Diag5';
        dim=50000;
        x0=1.1*ones(dim,1);
    case 8
        p='Diag5';
        dim=100000;
        x0=1.1*ones(dim,1);
    case 9
        p='Trecanni';
        dim=2;
        x0=[0.5;0.5];
        %x0=repmat([-5;10],[(dim/2), 1]); 
    case 10
        p='Trecanni';
        dim=2;
         x0=[1.05;1.05];
    case 11
        p='QP1';
        dim=4;
        x0=-1*ones(dim,1);
    case 12
        p='QP1';
        dim=100;
        x0=-1*ones(dim,1);
    case 13
        p='QP1';
        dim=10000;
        x0=-1*ones(dim,1);
    case 14
        p='QP2';
        dim=500;
        x0=10*ones(dim,1);
    case 15
        p='QP2';
        dim=10;
        x0=10*ones(dim,1);
    case 16
        p='QP2';
        dim=10;
        x0=10*ones(dim,1);
    case 17
        p='QF1';
        dim=10;
        x0=ones(dim,1);
    case 18
        p='QF1';
        dim=10;
        x0=ones(dim,1);
    case 19
        p='QF1';
        dim=10;
        x0=0.5*ones(dim,1);
    case 20
        p='QF2';
        dim=50;
        x0=ones(dim,1);
    case 21
        p='QF2';
        dim=1000;
        x0=ones(dim,1);
    case 22
        p='QF2';
        dim=5000;
        x0=ones(dim,1);
    case 23
        p='POWER';
        dim=2;
        x0=ones(dim,1);
   case 24
        p='POWER';
        dim=2;
        x0=15*ones(dim,1);
    case 25
         p='Zettl';
         dim=2;
         x0=[13;-0.013];
    case 26
         p='Diag2';
         dim=1000;
         x0=[1./(1:1:dim)]';
    case 27
         p='Diag2';
         dim=10000;
         x0=[1./(1:1:dim)]'; 
    case 28
         p='Diag2';
         dim=50000; 
         x0=[1./(1:1:dim)]'; 
    case 29
         p='Diag2';
         dim=100000; 
         x0=[1./(1:1:dim)]';
    case 30
         p='Test';
         dim=3;
         x0=[10;10;10];
    case 31
         p='Test';
         dim=3;
         x0=[7;7;7];
    case 32
         p='SumSqr';
         dim=100;
         x0=0.1*ones(dim,1);
     case 33
         p='SumSqr';
         dim=2000;
         x0=0.1*ones(dim,1);
     case 34
         p='SumSqr';
         dim=5000;
         x0=0.1*ones(dim,1);
    case 35
         p='Shallow';
         dim=1000;
         x0=10*ones(dim,1);
    case 36
         p='Shallow';
         dim=10000;
         x0=11*ones(dim,1);
    case 37
        p='QUARTC';
        dim=100;
        x0=0.23*ones(dim,1);
    case 38
        p='QUARTC';
        dim=1000;
        x0=0.23*ones(dim,1);
    case 39
        p='QUARTC';
        dim=5000;
        x0=0.15*ones(dim,1);
     case 40
        p='QUARTC';
        dim=10000;
        x0=0.15*ones(dim,1);
    case 41
        p='Matyas';
        dim=2;
        x0=[11;11];
    case 42
         p='Matyas';
         dim=2;
         x0=0.5*ones(dim,1);
    case 43
         p='Diag1';
         dim=10;
         x0=-33*ones(dim,1);
    case 44
         p='Diag1';
         dim=10;
          x0=-33*ones(dim,1);
    case 45
         p='Diag1';
         dim=10;
          x0=-21*ones(dim,1);
    case 46
         p='Diag1';
         dim=10;
         x0=-21*ones(dim,1);
    case 47
         p='Hager';
         dim=500;
         x0=0.7*ones(dim,1);
    case 48
         p='Hager';
         dim=300;
         x0=0.7*ones(dim,1);
     case 49
         p='Hager';
         dim=5000;
         x0=0.5*ones(dim,1);
    case 50
         p='Hager';
         dim=1000;
         x0=0.5*ones(dim,1);
     case 51
        p='ZAPF';
        dim=2;
         x0=0.30*ones(dim,1);
    case 52
         p='raydan1';
         dim=100;
         x0=ones(dim,1);
    case 53
         p='raydan1';
         dim=10;
         x0=ones(dim,1);
    case 54
         p='raydan1';
         dim=10;
         x0=-0.5*ones(dim,1);
    case 55
         p='raydan1';
         dim=50;
         x0=-0.5*ones(dim,1);
    case 56
         p='raydan2';
         dim=10000;
         x0=0.3*ones(dim,1);
     case 57
         p='raydan2';
         dim=50000;
         x0=0.3*ones(dim,1);
     case 58
         p='raydan2';
         dim=100000;
         x0=0.3*ones(dim,1);
    case 59
         p='FLETCHCR';
         dim=10;
         x0=0.99*ones(dim,1);
     case 60
         p='FLETCHCR';
         dim=1000;
         x0=0.99*ones(dim,1);
    case 61
         p='FLETCHCR';
         dim=50000;
         x0=0.99*ones(dim,1);
    case 62
         p='Diag3';
         dim=10;
         x0=13*ones(dim,1);
    case 63
         p='Diag3';
         dim=10;
         x0=13*ones(dim,1);
    case 64
         p='Diag3';
         dim=2;
         x0=11*ones(dim,1);
     case 65
         p='Diag3';
         dim=10;
         x0=11*ones(dim,1);
    case 66
         p='eDENSCHNB';
         dim=100;
         x0=0.03*ones(dim,1);
    case 67
         p='eDENSCHNB';
         dim=5000;
         x0=-0.03*ones(dim,1);
    case 68
         p='eDENSCHNB';
         dim=10000;
         x0=-0.03*ones(dim,1);
     case 69
         p='Diag6';
         dim=10000;
         x0=-1.01*ones(dim,1);
    case 70
         p='Diag6';
         dim=5000;
         x0=-1.01*ones(dim,1);
    case 71
         p='Diag6';
         dim=10000;
         x0=-1.03*ones(dim,1);
    case 72
         p='Diag6';
         dim=50000;
        x0=-1.03*ones(dim,1);
    case 73
        p='Diag4';
        dim=1000;
         x0=ones(dim,1);
    case 74
        p='Diag4';
        dim=10000;
         x0=ones(dim,1);
    case 75
        p='Diag4';
        dim=100000;
         x0=ones(dim,1);
    case 76
        p='Diag7';
        dim=10;
        x0=ones(dim,1);
    case 77
        p='Diag7';
        dim=100;
        x0=ones(dim,1);
    case 78
        p='Diag7';
        dim=100;
        x0=ones(dim,1);
    case 79
        p='Diag8';
        dim=100;
        %dim=10;
        x0=-0.5*ones(dim,1);
    case 80
        p='Diag8';
        dim=500;
        %dim=10;
        x0=-0.5*ones(dim,1);
    case 81
        p='Diag9';
        dim=10;
        x0=-7*ones(dim,1);
    case 82
        p='Diag9';
        dim=100;
        x0=-7*ones(dim,1);
    case 83
        p='DENSCHNA';
        dim=3000;
        x0=6*ones(dim,1);
     case 84
        p='DENSCHNA';
        dim=15000;
        x0=6*ones(dim,1);
      case 85 
        p='DENSCHNC';
        dim=1000;
        x0=100*ones(dim,1);
     case 86 
        p='DENSCHNC';
        dim=10000;
        x0=100*ones(dim,1);
     case 87
        p='BD1';
        dim=100;
        x0=5*ones(dim,1);
        %x0=13*ones(dim,1); %BETTER
     case 88
        p='BD1';
        dim=100;
        x0=5*ones(dim,1);
        %x0=13*ones(dim,1); %BETTER
     case 89
        p='BD1';
        dim=100;
        x0=5*ones(dim,1);
        %x0=13*ones(dim,1); %BETTER
     case 90
        p='HIMMELBH';
        dim=1000;
        x0=0.03*ones(dim,1);
     case 91
        p='HIMMELBH';
        dim=10000;
        x0=0.03*ones(dim,1);
    case 92
        p='HIMMELBH';
        dim=50000;
        x0=.02*ones(dim,1);
     case 93
        p='HIMMELBH';
        dim=10000;
        x0=.02*ones(dim,1);
     case 94
        p='DQDRTIC';
        dim=1000;
        x0=2*ones(dim,1);
     case 95
        p='DQDRTIC';
        dim=10000;
        x0=2*ones(dim,1);
      case 96
        p='DQDRTIC';
        dim=100;
        x0=11*ones(dim,1);
     case 97
        p='DQDRTIC';
        dim=10;
        x0=11*ones(dim,1);
     case 98
        p='QUARTICM';
        dim=1000;
        x0=0.03*ones(dim,1);
     case 99
        p='QUARTICM';
        dim=10000;
        x0=0.03*ones(dim,1);
      case 100
        p='LPerturbed';
        dim=5000;
        x0=13*ones(dim,1);
     case 101
        p='LPerturbed';
        dim=10000;
        x0=13*ones(dim,1);
     case 102
        p='LPerturbed';
        dim=20000;
        x0=13*ones(dim,1);
     case 103
        p='TWH'; 
        dim=2;
        %x0=100*ones(dim,1);
        x0=[-15;-15];
      case 104
        p='TWH'; 
        dim=2;
         x0=[-25;-0.25];
       case 105
        p='ENGVAL1';
        dim=2;
        x0=-1.01*ones(dim,1);
        %x0=0.5*ones(dim,1); %Better
      case 106
        p='ENGVAL1';
        dim=2;
        %x0=7*ones(dim,1);
        x0=-1.03*ones(dim,1); %Better
   case 107
        p='ENGVAL8';
        dim=4;
        %x0=1.02*ones(dim,1);
        x0=0.003*ones(dim,1); %Better
      case 108
        p='ENGVAL8';
        dim=2;
        %x0=11*ones(dim,1);
        x0=0.003*ones(dim,1); %Better
      case 109
        p='DENSCHNF';
        dim=1000;
        x0=.001*ones(dim,1);
     case 110
        p='DENSCHNF';
        dim=10000;
        x0=0.001*ones(dim,1);
     case 111
        p='DENSCHNF';
        dim=50000;
        x0=0.001*ones(dim,1);
      case 112
        p='ARWHEAD';
        dim=10;
        x0=7*ones(dim,1);
     case 113
        p='ARWHEAD';
        dim=100;
        x0=7*ones(dim,1);
     case 114
        p='ARWHEAD';
        dim=500;
        x0=7*ones(dim,1);   
     case 115
         p='Sixhump';
         dim=2;
         x0=[19;19];
         %x0=[-0.5;-0.5]; dprr
   case 116
         p='Sixhump';
         dim=2;
         %x0=[0.001;0.001];
       x0=[0.01;0.01]; 
     case 117
        p='Price4';
        dim=2;
        x0=-.03*ones(dim,1);
     case 118
        p='Price4';
        dim=2;
        x0=-0.01*ones(dim,1);   
     case 119
        p='ZAPF';
        dim=2;
        x0=0.31*ones(dim,1); 
     case 120
        p='ZAPF';
        dim=2;
         %x0=-0.003*ones(dim,1); 
         x0=0.29*ones(dim,1);
    case 121
         p='exhimmelblau';
         dim=500;
         x0=-8*ones(dim,1);
    case 122 
         p='exhimmelblau';
         dim=1000;
         x0=-8*ones(dim,1);
    case 123
         p='exhimmelblau';
         dim=2000;
         x0=-8*ones(dim,1);
   case 124 
         p='REF';
         dim=2;
         x0=[-0.0150;-0.0001];
   case 125  
         p='REF';
         dim=2;
         %x0=[-11;-11];
        % x0=0.03*ones(dim,1);
         x0=[0.03;0.009];
case 126  
         p='EVF';
         dim=2;
         x0=[11;11];
    case 127
        p='EVF'; 
        dim=2;
        x0=13*ones(dim,1);
   case 128
       p='eHiebert';
       dim=2;
       x0=[3,-6]';
    case 129
        p='ETridiag1';
        %p='EVF'; 
        dim=100;
        x0=-11*ones(dim,1);
    case 130
        p='ETridiag1';
        %p='EVF'; 
        dim=500;
        x0=-11*ones(dim,1);
    case 131
         p='Thump';
         dim=2;
        x0=[101;-101];
         %x0=[-0.5;-0.5]; dprp
    case 132
         p='Thump';
         dim=2;
         %x0=[0.001;0.001];
        x0=[0.001;0.001];
     %otherwise
        f='fnum'; %for any other problem
end 
%%%%%%%%%%%%%%%%%% defining initial points%%%%%%%%%%%%%%%%%%%%%%%
%guess=xnum;
%switch guess
%    case 1
        %x0=ones(dim,1);
%        x0=0.5*ones(dim,1);
        %x0=0.1*ones(dim,1);
%    case 2
 %       x0=0.1*ones(dim,1);
        %x0=(1./(2.^(1:dim)))';
 %   case 3
 %     x0=2*ones(dim,1);
 %   case 4
 %     x0=repmat([-1;1],[(dim/2), 1]);
 %   case 5
 %     x0=rand(dim,1); % random numbers between 0 and 1
%     otherwise
 %       x0=xnum; %for any other initial point
%end
%Step 0 Initialization
%g=feval(f,x0,1);
%f=feval(f,x0,0);
[g,~]=feval(p,x0);
norm_g=norm(g);
%[~,f]=feval(p,x0);
%f=sum(f);
nf=1; 
ng=1;
d=-g; %slope0=g'*d; 
%a1=0.5;
k=0;
x=x0;
c1 = .0001;
c2 = 0.5;
%tt=0.5;
%iota=10^30;
format long e
while (norm_g>.000001) && (k<2000)
    [Alpha,nfe] = St_Wolfe1m(p,x,d,c1,c2);
    %Alpha = St_Wolfe1(p,x,d,c1,c2);
    %alpha=armijo(p,x,d,a1);
    %alpha = mb_nocLineSearch(p,x,d,slope0,f);
    %Alpha=St_Wolfe1(p,x,d);
    %alpha=1;
    t=g; x0=x;
    x=x+Alpha*d;
    %g=feval(f,x,1);
    %f=feval(f,x,0);
    [g,~]=feval(p,x);
    norm_g=norm(g);
    nf=nf+1;
    ng=ng+1;
    %s=x-x0;
    y=g-t;
    Beta=(g'*y)/(d'*d);
    z=-((g'*d)/(norm(d)^2));
    d=-g+(Beta)+z*y;
    
  %  z=(d'*(g-t))/(norm(g)^2);
   % d=-z*g+Beta*d;
    nf=nfe+nf;
    %d=-g+Beta*d;
    k=k+1;
    
    %if k == 1
    %    fprintf('%6s %12s %16s\n','iter','f','beta');
    %    fprintf('%6.2f %12.8f %16.2f\n',k,f,Beta);
    %else
    %    fprintf('%6.2f %12.8f %16.2f\n',k,f,Beta);
    %end
end
disp([num2str(k) ' / ' num2str(nf) ' / '  num2str(ng) ' / ' num2str(toc)  ' / ' num2str(norm(g)) ])
disp([num2str(p)])
%disp([num2str(xx(1))])
  table1='wolfeexp.xlsx';
  T={num2str(k),num2str(nf),num2str(toc),num2str(norm(g))};
  sheet=1;
  xlRange=xlrange;
  xlswrite(table1,T,sheet,xlRange);

%disp([num2str(dim)])
%if k == 1
 %       fprintf('%6s %12s %16s\n','iter','f','beta');
   %      fprintf('%6.2f %12.8f %16.2f\n',k,f,Beta);
  %  else
   %     fprintf('%6.2f %12.8f %16.2f\n',k,f,Beta);
   % end  
  
toc;