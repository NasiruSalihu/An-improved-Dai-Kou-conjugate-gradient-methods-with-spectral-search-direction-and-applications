
function [Alpha, nfe] = St_Wolfe1m(p,x,d,c1,c2) % Alpha = St_Wolfe1m(p,x,d,c1,c2) %this version counts NOF
x0=x;
[f0,~,~]=feval(p,x0, [1 0 0]);
f0=sum(f0);

%nge=1; %added by me
nfe=1;
[~,grad0,~]=feval(p,x0, [0 1 0]);
g0 = grad0'*d;
%g0=sum(g0);%added by me
old = 0; fold = f0; gold = g0;
new = 1;
nexpand = max([50  -round(log2(norm(d)))]);
for k = 1:nexpand
   xnew = x0 + new*d;
   [fnew,~,~]=feval(p,xnew, [1 0 0]);
   fnew=sum(fnew);
   nfe=nfe+1;
   [~,gradnew,~]=feval(p,xnew, [0 1 0]);
   gnew = gradnew'*d;
   %gnew=sum(gnew); %added by me
   %nge=nge+1;%added by me
   if fnew > f0 + c1*new*g0 || ((fnew >= fold) && k > 1)   %
      [Alpha, nfee]= zoom1m(old, new, ...
          fold, fnew, gold, gnew, f0, g0, x0, d, p, c1, c2);
      nfe=nfe+nfee;
      %nge=nge+ngee; %added by me     
      return
   end
   if abs(gnew) <= c2*g0  
      Alpha = new; x = xnew; f = fnew; grad = gradnew; fail = 0; nfee = k;
      return
   end
   if gnew >= 0 
     [Alpha, nfee] =  zoom1m(new, old, ... 
          fnew, fold, gnew, gold, f0, g0, x0, d,p, c1, c2);
     nfe=nfe+nfee;
      return
   end
   old = new;       
   fold = fnew;
   gold = gnew;
   new = 2*new;     
end 
Alpha = new; 
x = xnew; 
f = fnew; 
grad = gradnew; 
fail = -1;
nsteps = 0;  