function [ outVal, outGr, outHes ] = New_func2( x0, VGH )

	n = length(x0);
	outVal = 0;
	outGr = 0;
	
	%constants
    
    if VGH(1) > 0
        outVal = outVal + 3*x0(1)^2 - 4*x0(1)*x0(2) + 2*x0(1)^2 + 4*x0(1)^2 + 6;
    end
    
     
    if VGH(2) > 0
        outGr = zeros(n, 1);
        outGr(1) = outGr(1) + 6*x0(1) - 4*x0(2) + 4*x0(1) + 4;
        outGr(2) = outGr(2) + (-4*x0(2));
    end
    
    
%     This Hessian is NOT for this function, therefore it should not be used
    if VGH(3) > 0
		outHes = zeros(n,n);

		for i=1:n
			outHes(i,i) = outHes(i,i) + 2*i;
		end
		outHes(1,1) = outHes(1,1) + (2*n)/c;
		outHes(1,n) = outHes(1,n) + (2*n)/c;
			
		outHes(n,1) = outHes(n,1) + (2*n)/c;
		outHes(n,n) = outHes(n,n) + (2*n)/c;
    else
        outHes = 0;
    end

    
end
