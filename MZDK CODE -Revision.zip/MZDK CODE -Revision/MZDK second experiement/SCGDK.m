function SCGDK(probnum,dimnum,xlrange)

%This is DK method
%A NONLINEAR CONJUGATE GRADIENT ALGORITHM WITH AN
%OPTIMAL PROPERTY AND AN IMPROVED WOLFE LINE
%SEARCH∗
%BY
%YU-HONG DAI† AND CAI-XIA KOU†
%SIAM J. OPTIM. c 2013 Society for Industrial and Applied Mathematics
%DOI. 10.1137/100813026
tic

if nargin<3
    xlrange='[]';
end
if nargin<2
    dimnum=1; %default dimension number
end
if nargin<1
    probnum=1; % default initial point
end
if nargin<1
    probnum=1; %default problem number
end

%%%%%%%%%%%%%%%% defining problems%%%%%%%%%%%%%%%%%%%%%%%%%%%
problem=probnum;
switch problem
    case 1
        f='GenRosenbrock';
    case 2
        f='GenWhiteHolst';
    case 3
        f='GenPSC1';
    case 4
        f='ExtPSC1';
    case 5
        f='ExtMaratos';
    case 6
        f='ExtWhiteHolst';
    case 7
        f='ExtRosenbrock';
    case 8
        f='CUBE';
    case 9
        f='Diagonal1';
    case 10
        f='Diagonal2';
    case 11
        f='Diagonal3';
    case 12
        f='Diagonal4';
    case 13
        f='Diagonal5';
    case 14
        f='Diagonal6';
    case 15
        f='Diagonal9';
    case 16
        f='DIXON3DQ';
    case 17
        f='ExtDENSCHNB';
    case 18
        f='Hager';
%     case 19
%         f='HIMMELHNew';=====
    case 19
        f='Raydan1';
    case 20
        f= 'Raydan2';
    case 21
        f='ExtTridiag2';
    case 22
        f='PertQuad';
    case 23
        f='ExtPen';
    case 24
        f='ExtHimmelblau';
    case 25
        f='ExtTridiag1';
    case 26
        f='GenTridiag1';
    case 27
        f='ExtPowell';
    case 28
        f='FullHessian2';
    case 29
        f='ExtBD1';
    case 30
        f='QuadQF1';
    case 31
        f='QUARTC';
    case 32
        f='ExtQuadPenQP1';
    case 33
        f='ExtHiebert';
%     case 35
%         f='QuadQF2';=====
    case 34
        f='FLETCHCR';
    case 35
        f='LIARWHD';
    case 36
        f='BDQRTIC';
    case 37
        f='TRIDIA';
    case 38
        f='ARWHEAD'; %'ARGLINB'
    case 39
        f='NONDIA';
    case 40
        f='NONDQUAR';
    case 41
        f='NONSCOMP';
    case 42
        f='DQDRTIC';
    case 43
        f='EG2';
%     case 46
%         f='SINENew';=====
%     case 47
%         f='SINQUADNew';====
    case 44
        f='PartPertQuad';
    case 45
        f='AlmostPertQuad';
    case 46
        f='PertTridiagQuad';
    case 47
        f='Staircase1';
%     case 52
%         f='Staircase2New';====
    case 48
        f='ExtFreudAndRoth';
    case 49
        f='ExtBeale';
    case 50
        f='ExtTET';
    case 51
        f='FullHessian1';
    case 52
        f='Staircase1';
    case 53
        f= 'ARGLINB'; %'ARWHEAD';
%     case 59
%         f='LIARWHD';=====
    case 54
        f='POWER';
    case 55
        f='ENGVAL1';
    case 56
        f='EDENSCH';
    case 57
        f='New_func';
    case 58
        f='New_func2';
    otherwise
        f='problem';
end

%%%%%%%%%%%%%%%%% defining dimension%%%%%%%%%%%%%%%%%%%%%%%%%%
% switch dimnum
%     case 1
%         dim=10;
%     case 2
%         dim=100;
%     case 3
%         dim=1000;
%     case 4
%         dim=10000;
%     case 5
%         dim=100000;
% %     case 6
% %         dim=1000000;
%     otherwise
%         dim=dimnum;    % for any other dimension not listed    
% end
switch dimnum
    case 1
        dim=10;
    case 2
        dim=200;
    case 3
        dim=500;
    case 4
        dim=1000;
    case 5
        dim=5000;
    otherwise
        dim=dimnum;    % for any other dimension not listed    
end
%%%%%%%%%%%%%%%%%% defining initial points%%%%%%%%%%%%%%%%%%%%%%%

initguess = probnum;
switch initguess
    case 1
        x0=repArray(dim,-1.2,1)';
    case 2
        x0=repArray(dim,-1.2,1)';
    case 3
        x0=repArray(dim,3,0.1)';
    case 4
        x0=repArray(dim,3,0.1)';
    case 5
        x0=repArray(dim,1.1,0.1)';
    case 6
        x0=repArray(dim,-1.2,1)';
    case 7
        x0=repArray(dim,-1.2,1)';
    case 8
        x0=repArray(dim,-1.2,1)';
    case 9
        x0=oneNumber(1/dim,dim)';
    case 10
        x0=expArray(dim,-1)';
    case 11
        x0=oneNumber(1,dim)';
    case 12
        x0=oneNumber(1,dim)';
    case 13
        x0=oneNumber(1.1,dim)';
    case 14
        x0=oneNumber(1,dim)';
    case 15
        x0=oneNumber(1,dim)';
    case 16
        x0=oneNumber(-1,dim)';
    case 17
        x0=oneNumber(1,dim)';
    case 18
        x0=oneNumber(1,dim)';
%     case 19
%         x0=oneNumber(1.5, initialDimension);
    case 19
        x0=oneNumber(1,dim)';
    case 20
        x0=oneNumber(1,dim)';
    case 21
        x0=oneNumber(1,dim)';
    case 22
        x0=oneNumber(0.5,dim)';
    case 23
        x0=aToB(1,dim)'; % return integers between a and b
    case 24
        x0=oneNumber(1,dim)';
    case 25
        x0=oneNumber(2,dim)';
    case 26
        x0=oneNumber(2,dim)';
    case 27
        x0=repArray(dim,3,-1,0,1)';
    case 28
        x0=oneNumber(0.01,dim)';
    case 29
        x0=oneNumber(0.1,dim)';
    case 30
        x0=oneNumber(1,dim)';
    case 31
        x0=oneNumber(2,dim)';
    case 32
        x0=oneNumber(1,dim)';
    case 33
        x0=oneNumber(0,dim)';
%     case 35
%         x0=oneNumber(0.5, initialDimension); 
    case 34
        x0=oneNumber(0,dim)';
    case 35
        x0=oneNumber(4,dim)';
    case 36
        x0=oneNumber(1,dim)';
    case 37
        x0=oneNumber(1,dim)';
    case 38
        x0=oneNumber(1,dim)';
    case 39
        x0=oneNumber(-1,dim)';
    case 40
        x0=repArray(dim,1,-1)';
    case 41
        x0=oneNumber(3,dim)';
    case 42
        x0=oneNumber(3,dim)';
    case 43
        x0=oneNumber(1,dim)';
%     case 46
%         x0= oneNumber(1, initialDimension);
%     case 47
%         x0=oneNumber(0.1, initialDimension);
    case 44
        x0=oneNumber(0.5,dim)';
    case 45
        x0=oneNumber(0.5,dim)';
    case 46
        x0=oneNumber(0.5,dim)';
    case 47
        x0=oneNumber(1,dim)';
%     case 52
%         x0=oneNumber(2, initialDimension);
    case 48
        x0=repArray(dim,0.5,-2)';
    case 49
        x0=repArray(dim,1,0.8)';
    case 50
        x0=oneNumber(0.1,dim)';
    case 51
        x0=oneNumber(0.01,dim)';
    case 52
        x0=oneNumber(1,dim)';
    case 53
        x0=oneNumber(1,dim)';
%     case 59
%         x0=oneNumber(4,initialDimension);
    case 54
        x0=oneNumber(1,dim)';
    case 55
        x0=oneNumber(2,dim)';
    case 56
        x0=oneNumber(0,dim)';
    case 57
        x0 = oneNumber(0, dim)';
    case 58
        x0 = oneNumber(0, dim)';
    otherwise
        x0=probnum; % for other problems
end

%%%%%%%%%%%%%%%%%% defining initial points%%%%%%%%%%%%%%%%%%%%%%%
% maximum inner iterations for the line search
Maxitc = 5000; maxit=5000;  % default maximum iterations for outer loop and inner loop resp.
tol=1e-6; % default tolarance
% initialization of the least possible value of alpha, memory "N" and etak
minalpha = 1e-3; eta_const = 0.01;
%  initialize the iteration counter and assigning up the initial point,
%  "x0"
itc=0; xc=x0; 
% for the line search 
c1=0.01; c2=0.1;
%c1=0.9; c2=0.1; %sigma1=c1, sigma2=c2
% first step length
alpha=1; %initial alpha
% function and gradient call
[val_fc,gc,~]=feval(f, xc, [1 1 0]);
numf=1;  numg=1;
inittry = 1;  kappa = 1e-4;
normg=norm(gc,inf);
% initial spectral parameter
dc=-gc; % initial direction
while(normg > tol && itc < Maxitc)
% while(normg > tol * ( 1 + abs(val_fc)) ) && ( itc < Maxitc)  
 %%     Line search procedure
    dd=gc'*dc;
    % initial step length as Nocedal & Wright 2ed. p.59
    if itc > 0
        alpha=alpha*(g0'*d0)/dd;
        %alpha=min(1,1.01*alpha);
    end
    [alpha, nfe] = STWolfe1Upd(f,xc,dc,c1,c2);
    numf = numf+nfe;
 %%    % update the iterate and compute necessary info at the new point
    xt = xc + alpha*dc;
    s  = xt - xc;
    [val_ft, gt, ~] = feval(f, xt, [1 1 0]); %gradient Jk^TFk
    numg=numg+1; numf=numf+1;
    y = gt - gc;
    
    
 %% computing the search direction  
    tauk=0.5*((gt'*dc)/norm(dc)^2);
    beta =(y'*gt)/(dc'*y)-((norm(y)^2/(s'*y))*((gt'*s)/(dc'*y))); 
    beta= max(beta, tauk);
    

    dt = -gt + beta*dc; 

% ------------------not useful-----------------------------------------
%     alpha0 = alpha*abs(s'*dt)/norm(dt);
%     normt = gt'*dt;
%     alpha0 = alpha*(dd/normt);  % Norcedal pp 58 Option I
%     alpha0 = (val_ft - val_fc)/normt; % Norcedal pp 58 Option II
% ---------------------------------------------------------------------
    xc=xt;
    dc=dt;
    gc=gt;  
    val_fc=val_ft;
    d0=dc;
    g0=gc;
    normg=norm(gc,inf);
    itc=itc+1;
end
toc
%  disp(xt)
    disp(['itc'     '/'     'numf'     '/'     'numg'     '/'      'toc'    '/'    'normg'     '/'     'val_fc'])
    disp([num2str(itc) ' / ' num2str(numf) ' / ' num2str(numg)   ' / '  num2str(toc)  ' / ' num2str(normg)  ' / '  num2str(val_fc)])
    if dimnum == [1 2 3 4 5]
        disp(num2str(dim))
    else
        disp(num2str(length(xc)))
    end
   disp(f)
  table2='ClassFirstExp_.xls';
  T={num2str(itc),num2str(numf),num2str(numg),num2str(toc),num2str(val_fc)};
 % %T={num2str(l),num2str(u)};
  sheet=3;
  xlRange=xlrange;
  xlswrite(table2,T,sheet,xlRange);
end
  
  % point_generators
function sp = oneNumber(number, dimension)
% returns number repeted dimesion times
sp = repmat(number, 1, dimension);
end


function sp = aToB(a, b)
% return integers between a and b
sp = linspace(a, b, b - a + 1);
end


function sp = expArray(dimension, exp)
% returns n^exp array with dimension elements
sp = zeros(1, dimension);
for i=1:dimension
    sp(i) = round(i^exp, 5, 'significant');
end
end


function sp = repArray(dimension, varargin)
% returns array with repeted provided elements of lentght dimension
% if no elements are provided returns zeros(1, dimension)
if nargin > 0
    aux = cell2mat(varargin);
    sp = repmat(aux, 1, round(dimension / length(aux)) + 1);
    sp = sp(1:dimension);
else
    sp = zeros(1, dimension);
end
end
 % %winopen(table2)