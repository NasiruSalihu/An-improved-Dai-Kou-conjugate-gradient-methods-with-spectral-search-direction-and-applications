function SCGHZ(probnum,dimnum,xlrange)


%This HZ method 
%A NEW CONJUGATE GRADIENT METHOD WITH
%GUARANTEED DESCENT AND AN EFFICIENT LINE SEARCH∗
%BY
%WILLIAM W. HAGER† AND HONGCHAO ZHANG†
%SIAM J. OPTIM. c 2005 Society for Industrial and Applied Mathematics

tic

if nargin<3
    xlrange='[]';
end
if nargin<2
    dimnum=1; %default dimension number
end
if nargin<1
    probnum=1; % default initial point
end
if nargin<1
    probnum=1; %default problem number
end
%%%%%%%%%%%%%%%% defining problems%%%%%%%%%%%%%%%%%%%%%%%%%%%
problem=probnum;
switch problem
    case 1
        f='GenRosenbrock';
    case 2
        f='GenWhiteHolst';
    case 3
        f='GenPSC1';
    case 4
        f='ExtPSC1';
    case 5
        f='ExtMaratos';
    case 6
        f='ExtWhiteHolst';
    case 7
        f='ExtRosenbrock';
    case 8
        f='CUBE';
    case 9
        f='Diagonal1';
    case 10
        f='Diagonal2';
    case 11
        f='Diagonal3';
    case 12
        f='Diagonal4';
    case 13
        f='Diagonal5';
    case 14
        f='Diagonal6';
    case 15
        f='Diagonal9';
    case 16
        f='DIXON3DQ';
    case 17
        f='ExtDENSCHNB';
    case 18
        f='Hager';
%     case 19
%         f='HIMMELHNew';=====
    case 19
        f='Raydan1';
    case 20
        f= 'Raydan2';
    case 21
        f='ExtTridiag2';
    case 22
        f='PertQuad';
    case 23
        f='ExtPen';
    case 24
        f='ExtHimmelblau';
    case 25
        f='ExtTridiag1';
    case 26
        f='GenTridiag1';
    case 27
        f='ExtPowell';
    case 28
        f='FullHessian2';
    case 29
        f='ExtBD1';
    case 30
        f='QuadQF1';
    case 31
        f='QUARTC';
    case 32
        f='ExtQuadPenQP1';
    case 33
        f='ExtHiebert';
%     case 35
%         f='QuadQF2';=====
    case 34
        f='FLETCHCR';
    case 35
        f='LIARWHD';
    case 36
        f='BDQRTIC';
    case 37
        f='TRIDIA';
    case 38
        f='ARGLINB';
    case 39
        f='NONDIA';
    case 40
        f='NONDQUAR';
    case 41
        f='NONSCOMP';
    case 42
        f='DQDRTIC';
    case 43
        f='EG2';
%     case 46
%         f='SINENew';=====
%     case 47
%         f='SINQUADNew';====
    case 44
        f='PartPertQuad';
    case 45
        f='AlmostPertQuad';
    case 46
        f='PertTridiagQuad';
    case 47
        f='Staircase1';
%     case 52
%         f='Staircase2New';====
    case 48
        f='ExtFreudAndRoth';
    case 49
        f='ExtBeale';
    case 50
        f='ExtTET';
    case 51
        f='FullHessian1';
    case 52
        f='Staircase1';
    case 53
        f='ARWHEAD';
%     case 59
%         f='LIARWHD';=====
    case 54
        f='POWER';
    case 55
        f='ENGVAL1';
    case 56
        f='EDENSCH';
    case 57
        f='New_func';
    case 58
        f='New_func2';
    otherwise
        f='problem';
end

%%%%%%%%%%%%%%%%% defining dimension%%%%%%%%%%%%%%%%%%%%%%%%%%
switch dimnum
    case 1
        dim=10;
    case 2
        dim=100;
    case 3
        dim=1000;
    case 4
        dim=10000;
    case 5
        dim=100000;
%     case 6
%         dim=1000000;
    otherwise
        dim=dimnum;    % for any other dimension not listed    
end
%%%%%%%%%%%%%%%%%% defining initial points%%%%%%%%%%%%%%%%%%%%%%%

initguess = probnum;
switch initguess
    case 1
        x0=repArray(dim,-1.2,1)';
    case 2
        x0=repArray(dim,-1.2,1)';
    case 3
        x0=repArray(dim,3,0.1)';
    case 4
        x0=repArray(dim,3,0.1)';
    case 5
        x0=repArray(dim,1.1,0.1)';
    case 6
        x0=repArray(dim,-1.2,1)';
    case 7
        x0=repArray(dim,-1.2,1)';
    case 8
        x0=repArray(dim,-1.2,1)';
    case 9
        x0=oneNumber(1/dim,dim)';
    case 10
        x0=expArray(dim,-1)';
    case 11
        x0=oneNumber(1,dim)';
    case 12
        x0=oneNumber(1,dim)';
    case 13
        x0=oneNumber(1.1,dim)';
    case 14
        x0=oneNumber(1,dim)';
    case 15
        x0=oneNumber(1,dim)';
    case 16
        x0=oneNumber(-1,dim)';
    case 17
        x0=oneNumber(1,dim)';
    case 18
        x0=oneNumber(1,dim)';
%     case 19
%         x0=oneNumber(1.5, initialDimension);
    case 19
        x0=oneNumber(1,dim)';
    case 20
        x0=oneNumber(1,dim)';
    case 21
        x0=oneNumber(1,dim)';
    case 22
        x0=oneNumber(0.5,dim)';
    case 23
        x0=aToB(1,dim)'; % return integers between a and b
    case 24
        x0=oneNumber(1,dim)';
    case 25
        x0=oneNumber(2,dim)';
    case 26
        x0=oneNumber(2,dim)';
    case 27
        x0=repArray(dim,3,-1,0,1)';
    case 28
        x0=oneNumber(0.01,dim)';
    case 29
        x0=oneNumber(0.1,dim)';
    case 30
        x0=oneNumber(1,dim)';
    case 31
        x0=oneNumber(2,dim)';
    case 32
        x0=oneNumber(1,dim)';
    case 33
        x0=oneNumber(0,dim)';
%     case 35
%         x0=oneNumber(0.5, initialDimension); 
    case 34
        x0=oneNumber(0,dim)';
    case 35
        x0=oneNumber(4,dim)';
    case 36
        x0=oneNumber(1,dim)';
    case 37
        x0=oneNumber(1,dim)';
    case 38
        x0=oneNumber(1,dim)';
    case 39
        x0=oneNumber(-1,dim)';
    case 40
        x0=repArray(dim,1,-1)';
    case 41
        x0=oneNumber(3,dim)';
    case 42
        x0=oneNumber(3,dim)';
    case 43
        x0=oneNumber(1,dim)';
%     case 46
%         x0= oneNumber(1, initialDimension);
%     case 47
%         x0=oneNumber(0.1, initialDimension);
    case 44
        x0=oneNumber(0.5,dim)';
    case 45
        x0=oneNumber(0.5,dim)';
    case 46
        x0=oneNumber(0.5,dim)';
    case 47
        x0=oneNumber(1,dim)';
%     case 52
%         x0=oneNumber(2, initialDimension);
    case 48
        x0=repArray(dim,0.5,-2)';
    case 49
        x0=repArray(dim,1,0.8)';
    case 50
        x0=oneNumber(0.1,dim)';
    case 51
        x0=oneNumber(0.01,dim)';
    case 52
        x0=oneNumber(1,dim)';
    case 53
        x0=oneNumber(1,dim)';
%     case 59
%         x0=oneNumber(4,initialDimension);
    case 54
        x0=oneNumber(1,dim)';
    case 55
        x0=oneNumber(2,dim)';
    case 56
        x0=oneNumber(0,dim)';
    case 57
        x0 = oneNumber(0, dim)';
    case 58
        x0 = oneNumber(0, dim)';
    otherwise
        x0=probnum; % for other problems
end


%[f,g,~]=feval(f, x0, [1 1 0]);

[~, g, ~] = feval(f, x0, [0 1 0]);
%[g,~]=feval(p,x0);
%numg=numg+1; numf=numf+1;
norm_g=norm(g);
%[~,f]=feval(p,x0);
%f=sum(f);
nf=1; 
ng=1;
d=-g; %slope0=g'*d; 
%a1=0.5;
k=0;
x=x0;
c1 = .01; c2 = 0.1;
%c1=0.9; c2=0.1;
%tt=0.5;
%iota=10^30;
format long e
while (norm_g>.000001) && (k<2000)
    [Alpha,nfe] = St_Wolfe1m(f,x,d,c1,c2);
    t=g; x0=x;
    x=x+Alpha*d;
    %g=feval(f,x,1);
    %f=feval(f,x,0);
    [~, g, ~] = feval(f, x0, [0 1 0]);
    %[g,~]=feval(p,x);
    norm_g=norm(g);
    nf=nf+1;
    ng=ng+1;
    s=x-x0;
    y=g-t;
    %y = gt - gc;
    eta_const = 0.01;    
    etak = -1 / (norm(d) * min(eta_const, norm(t)));

    %etak = -1/(norm(d)*min(eta_const, norm(t) ));
    numk  = (d'*y);
    betakN =  ((y'*g)/(numk) - (2*(g'*d)*norm(y)^2/numk^2));
    barbetakN = max(betakN, etak);
    dk = -g + barbetakN*d; 
    kappa = 1e-4; 
    
    if (g'*dk) >= -kappa*norm(g)*norm(dk)
        d = -g;
    end    
    nf=nfe+nf;
    k=k+1;
    
end

% disp([num2str(k) ' / ' num2str(nf) ' / '  num2str(ng) ' / ' num2str(toc)  ' / ' num2str(norm(g)) ])
% disp([num2str(p)])
% %disp([num2str(xx(1))])
%   table1='wolfeexp.xlsx';
%   T={num2str(k),num2str(nf),num2str(toc),num2str(norm(g))};
%   sheet=1;
%   xlRange=xlrange;
%   xlswrite(table1,T,sheet,xlRange);


 disp(['itc'     '/'     'numf'     '/'     'numg'     '/'      'toc'    '/'    'normg'     ])
    disp([num2str(k) ' / ' num2str(nf) ' / ' num2str(ng)   ' / '  num2str(toc)  ' / ' num2str(norm(g))])
    if dimnum == [1 2 3 4 5]
        disp(num2str(dim))
    else
        disp(num2str(length(x0)))
    end
   disp(f)
  table2='ClassFirstExp_.xls';
  T={num2str(k),num2str(nf),num2str(ng),num2str(toc)};
 % %T={num2str(l),num2str(u)};
  sheet=3;
  xlRange=xlrange;
  xlswrite(table2,T,sheet,xlRange);


toc;

% point_generators
function sp = oneNumber(number, dimension)
% returns number repeted dimesion times
sp = repmat(number, 1, dimension);
end


function sp = aToB(a, b)
% return integers between a and b
sp = linspace(a, b, b - a + 1);
end


function sp = expArray(dimension, exp)
% returns n^exp array with dimension elements
sp = zeros(1, dimension);
for i=1:dimension
    sp(i) = round(i^exp, 5, 'significant');
end
end


function sp = repArray(dimension, varargin)
% returns array with repeted provided elements of lentght dimension
% if no elements are provided returns zeros(1, dimension)
if nargin > 0
    aux = cell2mat(varargin);
    sp = repmat(aux, 1, round(dimension / length(aux)) + 1);
    sp = sp(1:dimension);
else
    sp = zeros(1, dimension);
end
end
end