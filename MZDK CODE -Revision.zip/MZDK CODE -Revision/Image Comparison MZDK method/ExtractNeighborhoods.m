function NhMat = ExtractNeighborhoods(N, X)
%
% column 1 of NhMat: 1st index of the neighbor of the kth noise
% column 2 of NhMat: 2nd index of the neighbor of the kth noise
% column 3 of NhMat: noise number k which is center of the neighborhood
% column 4 of NhMat: indicates if the neighbor is a noise (1) or not (-1)
% column 5 of NhMat: if the neighbor is a noise, clarifies its number in the noise list N
%

LN = length(N);

NhMat = zeros(4*LN,5);

for k = 1:LN
    
    Nh = Vij(N(k,1),N(k,2), X);
    
    w = (Nh(1:4,1) ~= 0);
    
    NhMat(4*k-3:4*k, 1:2) = Nh(1:4, 1:2);
    NhMat(4*k-3:4*k, 3) = k;
    FN=[FindN(Nh(1,1), Nh(1,2), N); FindN(Nh(2,1), Nh(2,2), N);...
        FindN(Nh(3,1), Nh(3,2), N); FindN(Nh(4,1), Nh(4,2), N)];
    NhMat(4*k-3:4*k, 4) = w .*FN(:,1);
    NhMat(4*k-3:4*k, 5) = w .*FN(:,2);
    
end

for kk = 1:4*LN
    
    if NhMat(kk, 4) == -1
        NhMat(kk, 5) = NhMat(kk, 3);
        % Trick: in the function gAlpha we get u(k) - u(k) = 0, no effect!
    end
    
end