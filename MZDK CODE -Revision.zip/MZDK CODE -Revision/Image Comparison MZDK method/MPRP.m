function [xk1, fk1, gk1, params] = MPRP( f, grad, x0, params)


% maximum inner iterations for the line search
Maxitc = params.Maxitc; alphaMax = params.maxit;  % default maximum iterations for outer loop and inner loop resp.
tol = params.tol; % default tolarance
% initialization of the least possible value of alpha, memory "N" and etak
%  initialize the iteration counter and assigning up the initial point,
%  "x0"
itc = params.itc; xc=x0;
% first step length
alpha = params.alpha0; %initial alpha
% function and gradient call
val_fc = feval(f, xc);
gc = feval(grad, xc);
numf = params.numf;  numg = params.numg;
eta_const = 0.1; 
% maximum inner iterations for the line search
innitmax=500;
% for the line search 
c1=0.001; c2=0.1; %sigma1=c1, sigma2=c2
bck = 0;
firsttrying = 1;
inittry = 1;  kappa = 0.3;
normg=norm(gc,inf);
% initial spectral parameter
dc=-gc; % initial direction
trace  = 0;
% while(normg > tol && itc < Maxitc)
while(normg > tol * ( 1 + abs(val_fc)) ) && ( itc < Maxitc)
      dd=gc'*dc;
%%  The call function of the Strong Wolfe line search strategy  
 % initial step length as Nocedal & Wright 2ed. p.59
%     if itc > 0
%         alpha=alpha*(g0'*d0)/dd;
%         %alpha=min(1,1.01*alpha);
%     end
%     
    if firsttrying
        Alpha0 = 1/norm(gc,inf);
        firsttrying = 0;
    else
        Alpha0 = norm(s0) / norm(d0);
    end

    % Strong Wolfe line search
%         [x_k1,alpha_k,f_k1,dfval,nfe,nge] = Wolfesearch2(f,df,x_k, d_k,Alpha0,delta,c2,f_k, g_k,trace);
    [x_k1,alpha,f_k1,dfval,nfe,nge] = Wolfesearch2(f,grad,xc, dc, Alpha0, delta,c2,val_fc, gc,trace);
    numf = numf+nfe;
    numg = numg+nge;
    
%%    % update the iterate and compute necessary info at the new point
    xt = xc + alpha*dc;
    s  = xt - xc;

%     [val_ft, gt] = feval(f, xt, [1 1]); %gradient Jk^TFk
    val_ft = feval(f, xt);
    gt = feval(grad, xt);
    numg=numg+1; numf=numf+1;
    y = gt - gc;
    
     %% computing the search direction    

    
    M=(2*(val_fc-val_ft)+s'*(gt+gc));
    y2=y+ (M*s/norm(s)^2);

    betaPRP= (gt'*y2)/norm(gc)^2;

    dt=-gt+betaPRP*dc;


    
    xc=xt;
    dc=dt;
    gc=gt;  
    val_fc=val_ft;
    d0=dc;
    g0=gc;
    s0=s;
   
    normg=norm(gc,inf);
    itc=itc+1;
end
% outputs
xk1=xc; 
fk1=val_fc;
gk1=gc;
params.numf = numf; params.numg = numg;







