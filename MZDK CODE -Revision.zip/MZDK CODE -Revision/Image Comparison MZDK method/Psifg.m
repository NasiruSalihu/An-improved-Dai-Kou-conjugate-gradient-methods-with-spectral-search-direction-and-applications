function [f, g] = Psifg(u, v)

global A NhMat

f = 0; % initialize the function value

LNM = length(NhMat);
gg = zeros(LNM,1);

    if v(1)>0
        for kk = 1:LNM

            if NhMat(kk,4)

                f = f + 0.5 * (1 + NhMat(kk,4))/2 * phi( u(NhMat(kk,3)) - u(NhMat(kk,5)) ) + ...
                    (1 - NhMat(kk,4))/2 * phi( u(NhMat(kk,3)) - A(NhMat(kk,1),NhMat(kk,2)) );
            end
        end  
    end

    if v(2)>0
        for kk = 1:LNM

            if NhMat(kk,4)
                gg(kk) = (1 + NhMat(kk,4))/2 * ( u(NhMat(kk,3)) - u(NhMat(kk,5)) ) / phi( u(NhMat(kk,3)) - u(NhMat(kk,5)) ) + ...
                       (1 - NhMat(kk,4))/2 * ( u(NhMat(kk,3)) - X(NhMat(kk,1),NhMat(kk,2)) ) / phi( u(NhMat(kk,3)) - X(NhMat(kk,1),NhMat(kk,2)) );      
            end
        end  

        LN = length(u);
        g = zeros(LN,1);

        for k = 1: LN

            g(k) = sum( gg(4*k-3:4*k) );

        end
    end

end
