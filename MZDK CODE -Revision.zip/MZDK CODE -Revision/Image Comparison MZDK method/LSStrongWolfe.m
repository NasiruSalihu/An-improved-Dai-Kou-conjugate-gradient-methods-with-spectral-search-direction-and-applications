function [alphaSt, nevalf, nevalg, it, success] = ...
    LSStrongWolfe(f, xc, d, val_fc, dd, alpha1, alphaMax, c1, c2, itmax, grad)
%
% Line search satisfying the strong Wolfe conditions, based on 
% Algorithms 3.5 (LS) and 3.6 (zoom) of Nocedal & Wright (2ed),
% together with elements from A6.3.1(mod) from Dennis & Schnabel.
%
% Coded by S. A. Santos for the experiments of the manuscript
% A structured diagonal Hessian approximation method with 
% evaluation complexity analysis for nonlinear least squares,
% joint work with H. Mohammad
%
% Last update: 11/July/2018
%

% initialize output to prevent error message
alphaSt = NaN; 
nevalf = 0;
nevalg = 0;
it = 1;
success = false;

% initialization of the left extreme of the interval, (cf. A6.3.1(mod) D&S)
alpha_L = 0;
val_L = val_fc;
slope = dd;

while (it < itmax && alpha1 < alphaMax && ~success)
    xt = xc + alpha1* d;
%     [~,ft] = feval(f,xt);
    val_ft = feval(f, xt);
    nevalf = nevalf+1;
%     val_ft = 0.5*(ft'*ft);    
    if ( val_ft > val_fc + c1*alpha1*dd )
        % The interval is bracketed: alpha1 is the right extreme of
        % the interval as it does not fulfill the Armijo condition
        [alphaSt,nf,ng,success] = ...
        zoomWolfe(alpha_L,alpha1,f,xc,val_fc,d,dd,val_L,val_ft,slope,c1,c2,success, grad);
        nevalf = nevalf+nf; nevalg = nevalg+ng;
    else
       % Since alpha1 verifies Armijo, we check if it also fulfills
       % the curvature condition.
       gt = feval(grad, xt);
%        [gt,~] = feval(f,xt);
       nevalg = nevalg+1;
       gtd=gt'*d;
       if (abs(gtd) <= -c2*dd)
         alphaSt = alpha1; success=true;
       else
         if (gtd >= 0)
           % The interval is bracketed: alpha1 is the right extreme
           % of the interval due to its positive curvature.
           [alphaSt,nf,ng,success] = ...
           zoomWolfe(alpha_L,alpha1,f,xc,val_fc,d,dd,val_L,val_ft,slope,c1,c2,success, grad);
           nevalf = nevalf+nf; nevalg = nevalg+ng;
         else
           % In this case, as the curvature remains negative,
           % we must increase the value of the step length.
           % We will double it as in D&S A.6.3.1(mod).
           % Recall that alpha1 satisfies Armijo, so the
           % left extreme of the interval will be also updated.
           alpha_L = alpha1; val_L = val_ft; 
           slope = gtd;
           alpha1 = min(2*alpha1,alphaMax);
         end
       end
    end
    it = it+1;
end
end