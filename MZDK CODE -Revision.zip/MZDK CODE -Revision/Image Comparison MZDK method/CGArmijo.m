function [fi,ng,ti,k]=CGArmijo(x0,OP1,OP2)
clear ti;
clear t;
clear g;
clear k;
clear f;
%global w   %w is gamma
tic
%This function for finding the minimizer of
%a given function with initial point x0
%OP1 for the type of Beta
%and OP2 for the test function
f=test_functions2(x0,OP2);
g=test_functions2(x0,OP2,1);

d=-g;
k=0;
x=x0';
while ((norm(g)>1e-6) && (k<1000))
    Alpha=Armijo(x,d,OP2);
    t=g;
    x=x+Alpha*d;
        g=test_functions2(x,OP2,1);   
        switch OP1
         case 'SD' 
    Beta=0;
        case 'RMIL'
        Beta=(g'*(g-t))/(d'*(d-g));
        case 'RMFI+'
        Beta=(g'*(g-t-d))/(d'*(d-g));
        case 'MMM'
    Beta=(g'*g)/(d'*(d-g));
        case 'SM'
            Beta=(g'*(g-(norm(g)/norm(t))*d-d))/(d'*(d-g));

        case 'RAMI'
        Beta=(g'*(g-(norm(g)/norm(t))*t))/(d'*(d-g));

        case 'SMO'
    Beta=(g'*g-(norm(g)/norm(t))*abs(g'*d))/( d'*(d-g));

        case 'RMIL*' %RMIL* AMC 2012
    Beta=(g'*(g-t))/(d'*d);

        case 'RMIL+'
            if (g'*g)>=abs(g'*t)

            Beta=(g'*(g-t))/(d'*d);
            else
                Beta=0;
            end
        case 'LAMR+'
            Beta=max(0,(g'*( (norm(d)/norm(d-g))*g-t)/((norm(d)/norm(d-g))*(d'*d) )));

        case 'SMR'
            Beta=max(0,(norm(g)^2 - abs(g'*t))/(d'*d) );
        case 'MRMIL' 
    Beta=(g'*(g-t-d))/(d'*d);
        case 'MMSIS'
           if (g'*g)>(norm(g)/norm(t)+1)*abs(g'*t)
    Beta=(g'*g-(norm(g)/norm(t)+1)*abs(g'*t))/(d'*d);
        else
            Beta=0;
           end

        case 'RMAR'
            Beta=(g'*(g-(norm(g)/norm(t))*d))/(d'*d);
        case 'AMRI'
    Beta=(g'*g-(norm(g)/norm(t))*abs((g'*t)))/(d'*d);


        case 'MMWA'
            Beta=(g'*g)/(d'*d);
        case 'MMWU'
            Beta=(g'*(g-t+d))/(d'*d);
        
        case 'DMR'
             if (g'*g)>=abs(g'*t)*norm(g)
    Beta=(g'*g-abs(g'*d)*norm(g))/(d'*d);
        else
            Beta=0;
             end
        case 'MALIK'
            Beta=(g'*(g-(norm(g)/norm(t))*g - g))/(g'*(g-d));
        case 'SMI'
           Beta=(g'*(g-(norm(g)/norm(t))*d - d))/(d'*d);
            
    case 'FR'
    Beta=(g'*g)/(t'*t);
    case 'PRP'
    Beta=(g'*(g-t))/(t'*t);
    case 'HS'
    Beta=(g'*(g-t))/(d'*(g-t));
    case 'CD'
    Beta=-(g'*g)/(d'*t);
    case 'DY'
    Beta=(g'*g)/(d'*(g-t));
    
    case 'LS'
    Beta=(g'*(g-t))/(-d'*t);
    
    case 'N1'
    Beta=(g'*(g-t))/(d'*d);
    case 'N3' %MMWU 
    Beta=(g'*g)/(d'*d);
    case 'N4'
    Beta=(norm(g,1)*norm(g,1))/(norm(t,1)*norm(t,1));
    case 'N5'
    d1=(g'*g)/(t'*t);
    d2=(g'*(g-t))/(t'*t);d3=(g'*(g-t))/(d'*(d-g));
    Beta=max(0,min(d1,d3)); %hybrid FR and RMIL
     case 'N7'
    Beta=(g'*g-(norm(g)/norm(t))*(g'*t))/(d'*d);
     case 'N8'
    Beta=(g'*(g-t))/(g'*g-2*g'*t+t'*t);
    case 'N9'
    Beta=max((g'*(g-t))/(d'*d),(g'*g-(norm(g)/norm(t))*(g'*t))/(t'*t));
    case 'N10'
    Beta=(g'*g-(norm(g)/norm(t))*(g'*t))/(t'*t);
    case 'N11'
    Beta=min((g'*(g-t))/(t'*t),(g'*g-(norm(g)/norm(t))*(g'*t))/(t'*t));
    case 'IB2'
    Beta=(g'*g-(norm(g)/norm(d))*(g'*d))/((t'*t)+0.1*abs(g'*d));
    case 'IMR'
    Beta=(g'*(g-t))/((g-d)'*(g-d));
    case 'CG_Descent'
            y=g-t;
               m1=-(1/(norm(d)*min(0.01,norm(t))));
               ganti=y-2*d*((norm(y)*norm(y))/(d'*y));
               m2=(1/(d'*y))*ganti'*g;
               Beta=max(m1,m2);
    otherwise
    error('Unknown Beta')
        end
    
  d=-g+Beta*d; %try, khadijah, Liu
   % d=-g+Beta*d;  % common search direction formula
  
  %d=-g+(Beta+BetaH)*d; %suggestion nov2017
 % d=-g+Beta*d-((g'*d)/(d'*(g-t)))*(g-t); %method 1
 %d=-g+Beta*d-((g'*d)/(t'*t))*(g-t); %method 2
    k=k+1
end
xi=x;
fi=f;
ng=norm(g);
ti=toc;