function [ output_args ] = number2letter( integer_)
% Scott Williams UTS Sydney 18-4-15
%number2letter(1) will return 'A', number2letter(26) will return 'Z'
%_
%Will convert a number to a letter. Written for xlwrite, mac code replacing xlswrite
%which fails on Mac. Drives the xlRange function also for xlwrite
% xlRange is packaged with this file in a .zip folder. Also available at Mathworks File Exchange
%xlwrite is presently available at Mathworks File Exchange: 
% http://www.mathworks.com/matlabcentral/fileexchange/38591-xlwrite--generate-xls-x--files-without-excel-on-mac-linux-win

%xlRange.m is available on Mathworks site

%Check if valid input
    if rem(integer_,1)~=0%Non integer entry if entry not divisible by 1
        sprintf('Invalid entry, non integer input\n\n')
        else %Entry is an integer
            if integer_ <1 %there are no letters before A, error handling
                output_args='Values less than 1 not accepted. Integer input must be valid';
            else
                    switch integer_ %The guts of what this function does follows
                        case ''%May or may not be useful
                            output_args='';
                        case 1
                            output_args='A';
                        case 2
                            output_args='B';
                        case 3
                            output_args='C';
                        case 4
                            output_args='D';
                        case 5
                            output_args='E';
                        case 6
                            output_args='F';
                        case 7
                            output_args='G';
                        case 8 
                            output_args='H';
                        case 9
                            output_args='I';
                        case 10
                            output_args='J';
                        case 11
                            output_args='K';
                        case 12
                            output_args='L';
                        case 13
                            output_args='M';
                        case 14
                            output_args='N';
                        case 15
                            output_args='O';
                        case 16
                            output_args='P';
                        case 17
                            output_args='Q';
                        case 18 
                            output_args='R';
                        case 19
                            output_args='S';
                        case 20
                            output_args='T';
                        case 21
                            output_args='U';
                        case 22
                            output_args='V';
                        case 23
                            output_args='W';
                        case 24
                            output_args='X';
                        case 25
                            output_args='Y';
                        case 26
                            output_args='Z';
                        otherwise 
                            output_args='Invalid number, integer input exceeds 26';
                    end
            end
    end
       
