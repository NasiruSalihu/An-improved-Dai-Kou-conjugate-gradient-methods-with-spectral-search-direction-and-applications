function phi1 = phi(t)

global alpha
phi1 = sqrt(t.^2 + alpha);

    
