function NF = FindN(i,j, N)
%
% Indicating if (i,j) is a noise position in N.
%

LN = length(N);

firsttrying = 1;

k = 1;

NF = [-1 0];

while k <= LN && firsttrying
    
    if N(k,1) == i && N(k,2) == j
        NF = [1 k];
        firsttrying = 0;
    end
    
    k = k + 1;
    
end