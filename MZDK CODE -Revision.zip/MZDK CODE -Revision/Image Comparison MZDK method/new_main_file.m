%       IMAGE RESTORATION OF AN IMAGE WITH SALT AND PEPPER IMPULSE NOISE
%		Author: Mahmoud M. Yahaya
%		Email: mahmoudpd@gmail.com
%		Date: 2024
clc
clear all 
close all


% noiselist = [.1,.2,.3,.4,.5,.6,.7,.8,.9];

noiselist = [.3,.7,.9];

for j = 1:1:length(noiselist)
    % default maximum iterations for outer loop and inner loop resp.
    params.Maxitc = 20000;
    params.maxit=10000; 
    % initialization of the least possible value of alpha, memory "N" and etak
    params.minalpha = 1e-3; params.tol = 1E-4;
    params.N = 5; 
    params.etak = 0.85;


    % for the nonmonotone line search 
    params.sigma = 1E-4;  
    params.lambda = 0.5; 
    % first step length
    params.alpha0=1; %initial alpha
    % iteration init count
    params.numf=1;  params.numg=1;
    params.itc = 0;
    params.rhomin = 1E-3; params.rhomax = 1E+5;
     %initial alpha
    params.alpha0 = 1;% first step length
    params.kappa = 1E-4;

    %% ----------------------Application params------------------------------------------------
    params.LambdaInit = 0.5;
    params.alpha = 4;
    params.fname = 'gAlpha';
    params.gfname = 'NablagAlpha';
    %% image properties and type of noise used
    imname =   'nasiru-pic.jpg'; %'mahmoud2.jpg'; % 'mahmoud.jpeg'; % 'triangulum-galazy2.jpg'; %ring-nebula2.jpg % pinwheel-galazy2.jpg %triangulum-galazy2.jpg %Mr.Mahmoud_Pic.jpg %kmutt1.jpg   ...
    %'camera256.tif' %monarch256   %cat256 %Pepper2256 %pepper1256 %pepper256  % bird256    %lena256   %goldhill256        % goldhill256       %camera256
    noise = 'salt & pepper'; 

    noise_degree = noiselist(j); % I need to vary this....

    X = imread(imname); % input image which is located in the same folder 
    % X = rgb2gray(X);  % comment this line if the imported image is black and white
    Xp = imnoise(X, noise, noise_degree); % The salt-and-pepper noise is injected by calling the imnoise command.

    %% resizing the image
    X = imresize(X,[256,256]); % useful for new  custom images 
    figure(1)
    hold on
    title('Original Image')
    imshow(X)
    if j == 1
        saveas(gcf,['orig-',imname],'epsc');
    end
    Xp = imresize(Xp,[256,256]);
    figure(2)
    hold on
    title([num2str(noiselist(j)*100,2),'% of Noise'])
    imshow(Xp);
    saveas(gcf,['noise-',num2str(noiselist(j)*100,2)],'epsc')
    % Extract the individual red, green and blue color channels from the
    % noisy image

    for i = 1:1:3
        [Medname,Img, RelEr, Tim] = restorefunc(X(:, :, i), Xp(:, :, i), params);
        RestOImg(:,:,i) = Img; 
        % metrics
        FReler(i) = RelEr;
        FTim(i)  = Tim;
    end
    NoicelessR = RestOImg(:,:,1); NoicelessG = RestOImg(:,:,2); RestOImgB = RestOImg(:,:,3);
    RestoredImg = cat(3, NoicelessR, NoicelessG, RestOImgB);
    %% Use to display the restored picture
    figure(3)
    hold on
    title('Recovered Image')
    imshow(RestoredImg);
    saveas(gcf,[Medname,'-resto-',num2str(noiselist(j)*100,2)],'epsc');
   %% Used for storing and exporting data into excel 
    table = 'Image-Rest2.xls'; 
%     fpsnr = mean(FPsnr); fssim =  mean(FSsim); fsnr = mean(FSnr); 
    [fssim, ~] = ssim(im2double(RestoredImg), im2double(X)); % structural similarity index, SSIM 
    [fpsnr, fsnr] = psnr(RestoredImg, X);
    frer = sum(FReler); ftm = sum(FTim);
    
    T={num2str(fpsnr),num2str(fssim), num2str(fsnr), num2str(frer), num2str(ftm)};
    solverNum = 2;
%     xlrange_=xlRange(solverNum,rowNum);
    xlrange_ = xlRange(solverNum,j);
    sheet  =  2;
    xlswrite(table,T,sheet,xlrange_);
    
    disp(fpsnr)
    disp(fssim)
    disp(fsnr) 
end
    function[Medname,Img, RelEr, Tim] = restorefunc(ImgO, ImgN, params)

    %     The function is use to perform the image restoration channel-wise and it takes the following:
    %     Inputs: 
    %         ImgO is the original input image
    %         IngN is the noise image corresponding to the ImgN
    %         params is a structure array used to store data type using containers called "fields", it can be thought of 
    %                as a dictionary with key:value pairs
    %      Output:
    %         Img is a restored image
    %         Reler is a relative error 
    %         Psnr is a signal-to-noise-ratio
    %         Tim is a time it tooks the algorithm to perform the restoration
    %         
    %%
    %     clear all;
    %     clc;

        global alpha A N m n LN NhMat
        %% parameter re-assignment
        alpha = params.alpha;
        LambdaInit = params.LambdaInit;
        fname = params.fname;
        gfname = params.gfname;
        A = ImgO;  Ap = ImgN; 
        %% pre-processing the image
        A = im2double(A); % takes an image as input, and returns an image of class double. 
        XS=A;     % XS is a Converted original image, A to double precision.
        Ap = im2double(Ap); % doing same for noisy image, Xp
%         NXS = Ap;  % NXS is a Converted noisy image, Ap to double precision.  
        [m, n] = size(A);

        [row, col, v] = find(A - Ap); %also returns a vector V containing the values
                                    % that correspond to the row and column indices I and J.
        LN = length(row);
        N = zeros(LN, 3);

        uInitial = zeros(LN, 1);

        for k = 1:LN
            N(k,1) = row(k);
            N(k,2) = col(k);
            N(k,3) = Ap(row(k),col(k));

            uInitial(k) = LambdaInit * A(row(k),col(k)) + (1 - LambdaInit) * Ap(row(k),col(k)); 
        end

        NhMat = ExtractNeighborhoods(N, A);

        t0 = tic;
                %Algos:    HZAlgo; DKAlgo; MDZK;
                % fname =  'Psifg';
                % gfname = 
        Algos = {'MPRP', 'HCG', 'MDZK'};
        [uopt, galphaopt, gradientopt, params] = MDZK(fname, gfname, uInitial, params);
        
        Medname= Algos{1}; % change the number 
        
        Tim = toc(t0);
        for k = 1:LN
            A(N(k,1),N(k,2))  = uopt(k);
        end
        Img = im2uint8(A); % im2uint8 takes an image as input, and returns an image of class uint8. i.e 
                           %i.e convert image to 8-bit unsigned integers.
%         [mx,nx]=size(A);
        A     = im2double(A);  % convert this 8-bit newly formed image, A to double precision
        D     = XS-A; % the diff. btw the originally converted double precision, XS and the newly recovered image
        RelEr = 100*norm(D)/norm(XS);

%         MSE = ((1/mx*nx)*norm(D,'fro')^2);
%         PSNR  = 10*log10((255^2)/(MSE) ); % peak signal to noise ratio
%         [SSIM, ~] = ssim(A, XS); % structural similarity index, SSIM 
        % ...its formular is SSIM(x=NOISY IMG, y=ORIGINAL IMG) = [l(x, y)^α * c(x, y)^β * s(x, y)^γ]
        % Compute the mean square error (MSE) between the original and processed images
%         MSE2 = mean((XS(:) - A(:)).^2);
%         SNR = 20*log10(mean(XS(:).^2)/(MSE2)); % 20*log10( intensity signal/ intensity noise)
        
        % Compute the histograms of the two images
%         hist1 = imhist(XS);
%         hist2 = imhist(A);

        % Normalize the histograms to make them probability density functions
%         pdf1 = hist1 / sum(hist1);
%         pdf2 = hist2 / sum(hist2);
     
        % Compute the relative entropy between the two probability density functions
%         RE = sum(pdf2.*log10(pdf2 ./ pdf1)); % A smaller relative entropy indicates..

        % Compute the relative entropy between the two probability density functions
%         RE = KLDiv(XS, A);
        % that the two images are more similar to each other.
end


