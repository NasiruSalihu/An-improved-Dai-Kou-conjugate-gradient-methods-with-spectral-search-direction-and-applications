function Nh = Vij(i, j, A)
%
% Finding neighbors of the node (i,j) of N in in NEWS format.
%

[m, n] = size(A);

if i-1 >= 1
    nd = [i-1, j, A(i-1,j)];
else
    nd = [0, 0, 0];
end

if j-1 >= 1
    wd = [i, j-1, A(i,j-1)];
else
    wd = [0, 0, 0];
end

if j+1 <= n
   ed = [i, j+1, A(i,j+1)];
else
    ed = [0, 0, 0];
end

if i+1 <= m
    sd = [i+1, j, A(i+1,j)];
else
    sd = [0, 0, 0];
end

Nh = [nd; ed; wd; sd];

