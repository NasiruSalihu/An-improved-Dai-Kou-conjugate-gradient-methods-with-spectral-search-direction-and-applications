function [xk1, fk1, gk1, params] = MDZK( f, grad, x0, params)
% Non Monotone CG with imaging application


% maximum inner iterations for the line search
Maxitc = params.Maxitc; alphaMax = params.maxit;  % default maximum iterations for outer loop and inner loop resp.
tol = params.tol; % default tolarance
% initialization of the least possible value of alpha, memory "N" and etak
%  initialize the iteration counter and assigning up the initial point,
%  "x0"
itc = params.itc; xc=x0;
% first step length
alpha = params.alpha0; %initial alpha
% function and gradient call
val_fc = feval(f, xc);
gc = feval(grad, xc);
numf = params.numf;  numg = params.numg;
eta_const = 0.1; 
% maximum inner iterations for the line search
innitmax=500;
% for the line search 
c1=0.001; c2=0.1; %sigma1=c1, sigma2=c2
bck = 0;
firsttrying = 1;
inittry = 1;  kappa = 0.2;
normg=norm(gc,inf);
% initial spectral parameter
dc=-gc; % initial direction
trace  = 0;
% while(normg > tol && itc < Maxitc)
while(normg > tol * ( 1 + abs(val_fc)) ) && ( itc < Maxitc)
      dd=gc'*dc;
%%  The call function of the Strong Wolfe line search strategy  
 % initial step length as Nocedal & Wright 2ed. p.59
%     if itc > 0
%         alpha=alpha*(g0'*d0)/dd;
%         %alpha=min(1,1.01*alpha);
%     end
%     
    if firsttrying
        Alpha0 = 1/norm(gc,inf);
        firsttrying = 0;
    else
        Alpha0 = norm(s0) / norm(d0);
    end

    % Strong Wolfe line search
%         [x_k1,alpha_k,f_k1,dfval,nfe,nge] = Wolfesearch2(f,df,x_k, d_k,Alpha0,delta,c2,f_k, g_k,trace);
    [x_k1,alpha,f_k1,dfval,nfe,nge] = Wolfesearch2(f,grad,xc, dc, Alpha0, delta,c2,val_fc, gc,trace);
    numf = numf+nfe;
    numg = numg+nge;
    
%     [alphaSt,nevalf,nevalg,it,success] = ...
%         LSStrongWolfe(f,xc,dc,val_fc,dd,alpha,alphaMax,c1,c2,innitmax, grad);
%     numf = numf+nevalf;
%     numg = numg+nevalg;
%     bck=bck+it;
%     if success
%        alpha = alphaSt;
%     else
%        disp('Bactracking error')
%        disp(f)
%        return;
%     end
%%    % update the iterate and compute necessary info at the new point
    xt = xc + alpha*dc;
    s  = xt - xc;

    val_ft = feval(f, xt);
    gt = feval(grad, xt);
    numg=numg+1; numf=numf+1;
    y = gt - gc;
     %% computing the search direction
    num1 = gt'*y; num2 = dc'*y;
    betak = num1/num2 - norm(y)^2/(s'*y)*((gt'*s)/num2);
    eta = 0.5;
    betakplus = max(betak, eta*(gt'*dc)/norm(dc)^2);
    dt = -gt + betakplus*dc; 

    if abs(gt'*gc) >= -kappa*norm(gt)*norm(gt)^2
        dt = -gt;
    end
% ------------------not useful-----------------------------------------
%     alpha0 = alpha*abs(s'*dt)/norm(dt);
%     normt = gt'*dt;
%     alpha0 = alpha*(dd/normt);  % Norcedal pp 58 Option I
%     alpha0 = (val_ft - val_fc)/normt; % Norcedal pp 58 Option II
% ---------------------------------------------------------------------
    xc=xt;
    dc=dt;
    gc=gt;  
    val_fc=val_ft;
    d0=dc;
    g0=gc;
    s0=s;
   
    normg=norm(gc,inf);
    itc=itc+1;
end
% outputs
xk1=xc; 
fk1=val_fc;
gk1=gc;
params.numf = numf; params.numg = numg;







