function zero_residual_error_plot(T, logplot)
% written by name:  Mahmoud M. Yahaya;
%            email: mahmoudpd@gmail.com
% the zero_residual_error_plot() function plot the zero residuals obtained
% from NLS algorithms.
% Date: 02/05/2022
% inputs: T is the zero residual data table, where each column correspond to... 
% a solver(algorithm)'s residual values for all the problems solved.
%         logplot specify the log scale on the x-axis, if used, its usage is obtional 
if (nargin < 2) 
    logplot = 0; 
end

max_ratio = max(max(T)); % use to get maximum value within the whole table
T(isnan(T)) = 2*max_ratio; % this operation replaces the failure cases with the max_ratio

% T = sort(T, 'descend'); % use to sort the data in descending
xs = [10, 20, 30, 40, 50, 60, 70, 80, 90];

plot(xs,T(:,1),'--*r',xs,T(:,2),':+',xs,T(:,3),'c:o','LineWidth',2,...
                       'MarkerEdgeColor','k',...
                       'MarkerFaceColor','g',...
                       'MarkerSize',8)

% axis([10,90,0,85]) % [xmin,xmax, ymin,ymax] with PSNR and SNR
% axis([10,90,0,1]) % [xmin,xmax, ymin,ymax] with SSIM
axis([10,90,0,4]) % [xmin,xmax, ymin,ymax] with CPUT
% axis([10,90,0,20]) % [xmin,xmax, ymin,ymax] with Rel error

xlabel('\% of Noise')
ylabel('CPUT')
% ylabel('Rel. error')
% ylabel('SNR(dB)')
% ylabel('SSIM')
% ylabel('PSNR(dB)')
grid on
end