function [xopt, fopt, gopt, NI, Nf] = Alg (f, df, x0, AlgNo, Tolerance, CRestart, MaxIter, delta, ro, minimumofalpha, maxiter)
%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x_k  = x0;
f_k = feval(f, x_k);
g_k = feval(df, x_k);
Nf = 1;
NI = 0;
d_k  = -g_k;
firsttrying = 1;
trace = 0;
c2=0.9;
while ( norm(g_k,inf) > Tolerance * (1+abs(f_k)) ) &&  ( NI<MaxIter )
    
    if firsttrying
        Alpha0 = 1/norm(g_k,inf);
        firsttrying = 0;
    else
        Alpha0 = norm(s_1k) / norm(d_k);
    end

   % [alpha_k, f_k1, x_k1, nfe] = BacktrackingArmijo2(f, x_k, d_k, delta, Alpha0, f_k, g_k, ro, minimumofalpha, maxiter);
    [x_k1,alpha_k,f_k1,dfval,nfe,nge] = Wolfesearch2(f,df,x_k, d_k,Alpha0,delta,c2,f_k, g_k,trace);
    NI = NI + 1;
    Nf = Nf + nfe;
    
   % fprintf( '\t Norm of gradient: %6.4e          NI = Ng:%4.0f          Nf:%4.0f', norm(g_k, inf), NI, Nf)
    
    s_k = alpha_k * d_k; 
    g_k1 = feval(df, x_k1);
    y_k = g_k1 - g_k;
    
    switch AlgNo
        
        case 1
            beta=(g_k1'*y_k)/(d_k'*y_k);
   %-----------------------------------------------------------------------
        case 2
             beta=(g_k1'*y_k)/(d_k'*d_k);
   %-----------------------------------------------------------------------
        case 3
             beta=(g_k1'*y_k)/(g_k'*t_k);
   %-----------------------------------------------------------------------     
        case 4
             %beta=(g_k1'*y_k)/(g_k'*t_k);
        beta=max(0,(g_k'*(((norm(d_k)/norm(d_k-g_k1))*g_k1)-g_k)))/((norm(d_k)/norm(d_k-g_k1))*(norm(d_k)^2));
   
    end
    d_k1 = -g_k1 + beta * d_k;
    %----------------------------------------------------------------------
    %Next direction computation
    %----------------------------------------------------------------------
    % Restart:
%     if d_k1'*g_k1 > - CRestart * norm(d_k1) * norm(g_k1)
%         d_k1 = - g_k1;
%     end
    %----------------------------------------------------------------------
    % k <----- k + 1
    %----------------------------------------------------------------------
    s_1k = s_k;
    x_k = x_k1;
    f_k = f_k1;
    g_k = g_k1;
    d_k = d_k1;
    
    %----------------------------------------------------------------------
    
end

xopt = x_k;
fopt = f_k;
gopt = g_k;
