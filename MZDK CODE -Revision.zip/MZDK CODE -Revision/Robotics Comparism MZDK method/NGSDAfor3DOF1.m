function NGSDAfor3DOF1()
% Mahmoud Muhammad Yahaya's 3DOF  model implementation solve via NLS algo.
% mahmoudpd@gmail.com
clear;
t0 = 0;
tf = 20; % [0, 20s]
g = 0.05; % sampling period
Kmax = (tf - t0)/g; % 

theta0 = [0, pi/3, pi/2];
thetamah1 = theta0;
thetamah2 = theta0;
thetamah3 = theta0;
thetamah4 = theta0;
thetamah5 = theta0;
thetamah6 = theta0;
%thetamah7 = theta0;


for k = 1:Kmax
    tk = k*g;
    rd = [1.5 + 0.4*sin(pi*tk/5), sqrt(3)/2 + 0.4*sin(pi*tk/5 +   pi/3)]'; % ring
    thetak1 = NGSDA1(rd, thetamah1(end,:)');
    thetak2 = NGSDA2(rd, thetamah2(end,:)');
    thetak3 = NGSDA3(rd, thetamah3(end,:)');
    thetak4 = NGSDA4(rd, thetamah4(end,:)');
    thetak5 = NGSDA5(rd, thetamah5(end,:)');
    thetak6 = NGSDA6(rd, thetamah6(end,:)');
%    thetak7 = NGSDA7(rd, thetamah6(end,:)');


    thetamah1 = [thetamah1; thetak1']; % a matrix of joint angular vectors
    thetamah2 = [thetamah2; thetak2']; % a matrix of joint angular vectors
    thetamah3 = [thetamah3; thetak3']; % a matrix of joint angular vectors
    thetamah4 = [thetamah4; thetak4']; % a matrix of joint angular vectors
    thetamah5 = [thetamah5; thetak5']; % a matrix of joint angular vectors
    thetamah6 = [thetamah6; thetak6']; % a matrix of joint angular vectors
 %   thetamah7 = [thetamah7; thetak6']; % a matrix of joint angular vectors

end

x0 = zeros(Kmax+1,3);
x1 = [cos(thetamah1(:,1)), sin(thetamah1(:,1))];
x2 = [cos(thetamah1(:,1)) + cos(thetamah1(:,1) + thetamah1(:,2)), sin(thetamah1(:,1)) + sin(thetamah1(:,1) + thetamah1(:,2))];
% first algorithm's model of end-effector
x3 = [cos(thetamah1(:,1)) + cos(thetamah1(:,1) + thetamah1(:,2)) + cos(thetamah1(:,1) + thetamah1(:,2) + thetamah1(:,3)), sin(thetamah1(:,1)) + sin(thetamah1(:,1) + thetamah1(:,2)) + sin(thetamah1(:,1) + thetamah1(:,2)+ thetamah1(:,3))];
% second algorithm's model of end-effector
x4 = [cos(thetamah2(:,1)) + cos(thetamah2(:,1) + thetamah2(:,2)) + cos(thetamah2(:,1) + thetamah2(:,2) + thetamah2(:,3)), sin(thetamah2(:,1)) + sin(thetamah2(:,1) + thetamah2(:,2)) + sin(thetamah2(:,1) + thetamah2(:,2)+ thetamah2(:,3))];
% third algorithm's model of end-effector
x5 = [cos(thetamah3(:,1)) + cos(thetamah3(:,1) + thetamah3(:,2)) + cos(thetamah3(:,1) + thetamah3(:,2) + thetamah3(:,3)), sin(thetamah3(:,1)) + sin(thetamah3(:,1) + thetamah3(:,2)) + sin(thetamah3(:,1) + thetamah3(:,2)+ thetamah3(:,3))];
% fourth algorithm's model of end-effector
x6 = [cos(thetamah4(:,1)) + cos(thetamah4(:,1) + thetamah4(:,2)) + cos(thetamah4(:,1) + thetamah4(:,2) + thetamah4(:,3)), sin(thetamah4(:,1)) + sin(thetamah4(:,1) + thetamah4(:,2)) + sin(thetamah4(:,1) + thetamah4(:,2)+ thetamah4(:,3))];
x7 = [cos(thetamah5(:,1)) + cos(thetamah5(:,1) + thetamah5(:,2)) + cos(thetamah5(:,1) + thetamah5(:,2) + thetamah5(:,3)), sin(thetamah5(:,1)) + sin(thetamah5(:,1) + thetamah5(:,2)) + sin(thetamah5(:,1) + thetamah5(:,2)+ thetamah5(:,3))];
x8 = [cos(thetamah6(:,1)) + cos(thetamah6(:,1) + thetamah6(:,2)) + cos(thetamah6(:,1) + thetamah6(:,2) + thetamah6(:,3)), sin(thetamah6(:,1)) + sin(thetamah6(:,1) + thetamah6(:,2)) + sin(thetamah6(:,1) + thetamah6(:,2)+ thetamah6(:,3))];
%x9 = [cos(thetamah7(:,1)) + cos(thetamah7(:,1) + thetamah7(:,2)) + cos(thetamah7(:,1) + thetamah7(:,2) + thetamah7(:,3)), sin(thetamah7(:,1)) + sin(thetamah7(:,1) + thetamah7(:,2)) + sin(thetamah7(:,1) + thetamah7(:,2)+ thetamah7(:,3))];


figure
for k = 1:Kmax
    plot([x0(k,1); x1(k,1)],[x0(k,2); x1(k,2)],'r');
    grid on
    hold on
    plot([x1(k,1); x2(k,1)],[x1(k,2); x2(k,2)],'g');
    grid on
    hold on
    plot([x2(k,1); x3(k,1)],[x2(k,2); x3(k,2)],'b');
    grid on
    
end
% plot that draw the Lassajous curve at the end- effector
rdz = [];
for k = 0:Kmax
    tk = k*g;
    rd = [1.5 + 0.4*sin(pi*tk/5), sqrt(3)/2 + 0.4*sin(pi*tk/5 + pi/3)]; % ring
    rdz = [rdz; rd];
end

%Added by me to include other methods
figure
plot(rdz(:,1),rdz(:,2),'ob', x3(:,1),x3(:,2),'-.r');
legend('Desired path','Actual trajectory')
grid on

figure
semilogy(abs(x3(:,1) - rdz(:,1)), 'MarkerSize',2,'LineWidth',1.5)
% legend('NSFR')
grid on
hold on;
semilogy(abs(x4(:,1) - rdz(:,1)), 'MarkerSize',1,'LineWidth',1.5)
% legend('HZ')
grid on
hold on;
semilogy(abs(x5(:,1) - rdz(:,1)), 'MarkerSize',1,'LineWidth',1.5)
% legend('FR')
grid on
hold on;
semilogy(abs(x6(:,1) - rdz(:,1)), 'MarkerSize',1,'LineWidth',1.5)
axis([0,200,0,1])

semilogy(abs(x7(:,1) - rdz(:,1)), 'MarkerSize',1,'LineWidth',1.5)
axis([0,200,0,1])

semilogy(abs(x8(:,1) - rdz(:,1)), 'MarkerSize',1,'LineWidth',3.5)
axis([0,200,0,1])


%semilogy(abs(x9(:,1) - rdz(:,1)), 'MarkerSize',1,'LineWidth',1.5)
%axis([0,200,0,1])

legend('MZDK','HZ', 'DK','MPRP', 'HCG', 'ZDK')
grid on

figure
semilogy(abs(x3(:,2) - rdz(:,2)), 'MarkerSize',2,'LineWidth',1.5)
grid on
hold on;
semilogy(abs(x4(:,2) - rdz(:,2)), 'MarkerSize',1,'LineWidth',1.5)
grid on
hold on;
semilogy(abs(x5(:,2) - rdz(:,2)), 'MarkerSize',1,'LineWidth',1.5)
grid on
hold on;
semilogy(abs(x6(:,2) - rdz(:,2)), 'MarkerSize',1,'LineWidth',1.5)
grid on
hold on;
semilogy(abs(x7(:,2) - rdz(:,2)), 'MarkerSize',1,'LineWidth',1.5)

grid on
hold on;
semilogy(abs(x8(:,2) - rdz(:,2)), 'MarkerSize',1,'LineWidth',3.5)

%grid on
%hold on;
%semilogy(abs(x9(:,2) - rdz(:,2)), 'MarkerSize',1,'LineWidth',1.5)

axis([0,200,0,1])
legend('MZDK','HZ', 'DK','MPRP', 'HCG', 'ZDK')
grid on
