function alphak = Armijo(x,d,OP)
alphak = 1;
rho=1/2;
c=0.0001;
fk = test_functions(x,OP);
gk = test_functions(x,OP,1);
xx = x;
x = x + alphak*d;
fk1 = test_functions(x,OP);
while fk1 > fk + c*alphak*gk'*d
  alphak = alphak*rho;
  x = xx + alphak*d;
  fk1 = test_functions(x,OP);
end