function alpha = St_WolfeN2(xk, rd, gk, dk, fkz   )

c1 = 0.01;
c2 = 0.001;
dd = gk'*dk;
if dd >= 0
  error('g0 must be negative, not a descent direction')
end

old = 0; fold = fkz; gold = dd;
tk = 1;
nexpand = max([50  -round(log2(norm(dk)))]);
for k = 1:nexpand
   xkn = xk + tk*dk;
   rkn = [cos(xkn(1)) + cos(xkn(1) + xkn(2)) + cos(xkn(1) + xkn(2) + xkn(3)); sin(xkn(1)) + sin(xkn(1) + xkn(2)) + sin(xkn(1) + xkn(2) + xkn(3))] - rd;

   fkzn= 0.5*norm(rkn,2)^2;  % test_functions(xkn,op);  
   Jkn = [-sin(xkn(1))-sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2)+xkn(3)); cos(xkn(1))+cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2)+xkn(3))];
   gkn = Jkn'*rkn;
   gnew = gkn'*dk;
   if fkzn > fkz + c1*tk*dd | ((fkzn >= fold) & k > 1)   %
      [alpha, x, f, grad, fail, nsteps] = nzoom1(old, tk, ...
          fold, fkzn, gold, gnew, fkz, dd, xk, dk, rd, c1, c2);
      return
   end
   if abs(gnew) <= c2*dd  
      alpha = tk; x = xkn; f = fkzn; grad = gradnew; fail = 0; nsteps = k;
      return
   end
   if gnew >= 0     
      [alpha, x, f, grad, fail, nsteps] = nzoom1(tk, old, ... 
          fkzn, fold, gnew, gold, fkz, dd, xk, dk,rd, c1, c2);
      return
   end
   old = tk;       
   fold = fkzn;
   gold = gnew;
   tk = 2*tk;     
end 
alpha = tk; 
% x = xnew; 
% f = fnew; 
% grad = gradnew; 
% fail = -1;
% nsteps = 0;  
