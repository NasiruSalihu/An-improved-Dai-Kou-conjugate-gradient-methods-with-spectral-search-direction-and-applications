function xk = NGSDA3(rd, x0)

%This is DK method
%A NONLINEAR CONJUGATE GRADIENT ALGORITHM WITH AN
%OPTIMAL PROPERTY AND AN IMPROVED WOLFE LINE
%SEARCH∗
%BY
%YU-HONG DAI† AND CAI-XIA KOU†
%SIAM J. OPTIM. c 2013 Society for Industrial and Applied Mathematics
%DOI. 10.1137/100813026


% initializations
xk = x0;
iter = 0;

rk = [cos(xk(1)) + cos(xk(1) + xk(2)) + cos(xk(1) + xk(2) + xk(3)); sin(xk(1)) + sin(xk(1) + xk(2)) + sin(xk(1) + xk(2) + xk(3))] - rd;
fkz = 1/2*norm(rk,2)^2;
% Initial Jacobian matrix
Jk = [-sin(xk(1))-sin(xk(1)+xk(2))-sin(xk(1)+xk(2)+xk(3)) -sin(xk(1)+xk(2))-sin(xk(1)+xk(2)+xk(3)) -sin(xk(1)+xk(2)+xk(3)); cos(xk(1))+cos(xk(1)+xk(2))+cos(xk(1)+xk(2)+xk(3)) cos(xk(1)+xk(2))+cos(xk(1)+xk(2)+xk(3)) cos(xk(1)+xk(2)+xk(3))];
% Gradient function gk = J'F
gk = Jk'*rk;
% Initiate b
%Initial Direction
dk = -gk;
normg = norm(gk, inf);
while (normg > 10^(-5)&&iter<=1000)          %( norm(fk) > 10^(-5)*sqrtn + 10^(-4)*norm(f0) )

% This while loop will find a suitable step (Strong Wolfe line search)        
   alpha = St_WolfeN2(xk, rd, gk, dk, fkz );
   xkn = xk + alpha*dk;
   rkn = [cos(xkn(1)) + cos(xkn(1) + xkn(2)) + cos(xkn(1) + xkn(2) + xkn(3)); sin(xkn(1)) + sin(xkn(1) + xkn(2)) + sin(xkn(1) + xkn(2) + xkn(3))] - rd;

   fkzn= 0.5*norm(rkn,2)^2;  % test_functions(xkn,op);  
   Jkn = [-sin(xkn(1))-sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2)+xkn(3)); cos(xkn(1))+cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2)+xkn(3))];
   gkn = Jkn'*rkn;
   
   s=xkn-xk;
   t = gk;
   g = gkn;
   d = dk;
   y=g-t;
   
   
   tauk=0.5*((g'*d)/norm(d)^2);
   beta =(y'*g)/(d'*y)-((norm(y)^2/(s'*y))*((g'*s)/(d'*y))); 
   beta= max(beta, tauk);
    
  
   dkn =-g+beta*d;

     % updating the values of xc, gc, f's, Q & C
    dk = dkn;
    fkz = fkzn;
    xk = xkn;
    gk = gkn;
    iter = iter +1;  
    normg=norm(gk,inf);

end