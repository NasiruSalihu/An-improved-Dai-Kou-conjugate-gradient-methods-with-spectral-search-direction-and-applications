function xk = NGSDA7(rd, x0)

%This is SHCG2 method
%Two efficient spectral hybrid CG methods based on
%memoryless BFGS direction and Dai–Liao conjugacy condition
%by
%Pengjie Liua,b, Zihang Yuana, Yue Zhuoa and Hu Shaoa
%OPTIMIZATION METHODS & SOFTWARE
%https://doi.org/10.1080/10556788.2024.2364203


% initializations
xk = x0;
iter = 0;

rk = [cos(xk(1)) + cos(xk(1) + xk(2)) + cos(xk(1) + xk(2) + xk(3)); sin(xk(1)) + sin(xk(1) + xk(2)) + sin(xk(1) + xk(2) + xk(3))] - rd;
fkz = 1/2*norm(rk,2)^2;
% Initial Jacobian matrix
Jk = [-sin(xk(1))-sin(xk(1)+xk(2))-sin(xk(1)+xk(2)+xk(3)) -sin(xk(1)+xk(2))-sin(xk(1)+xk(2)+xk(3)) -sin(xk(1)+xk(2)+xk(3)); cos(xk(1))+cos(xk(1)+xk(2))+cos(xk(1)+xk(2)+xk(3)) cos(xk(1)+xk(2))+cos(xk(1)+xk(2)+xk(3)) cos(xk(1)+xk(2)+xk(3))];
% Gradient function gk = J'F
gk = Jk'*rk;
% Initiate b
%Initial Direction
dk = -gk;
normg = norm(gk, inf);
while (normg > 10^(-5)&&iter<=1000)          %( norm(fk) > 10^(-5)*sqrtn + 10^(-4)*norm(f0) )

% This while loop will find a suitable step (Strong Wolfe line search)        
   alpha = St_WolfeN2(xk, rd, gk, dk, fkz );
   xkn = xk + alpha*dk;
   rkn = [cos(xkn(1)) + cos(xkn(1) + xkn(2)) + cos(xkn(1) + xkn(2) + xkn(3)); sin(xkn(1)) + sin(xkn(1) + xkn(2)) + sin(xkn(1) + xkn(2) + xkn(3))] - rd;

   fkzn= 0.5*norm(rkn,2)^2;  % test_functions(xkn,op);  
   Jkn = [-sin(xkn(1))-sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2)+xkn(3)); cos(xkn(1))+cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2)+xkn(3))];
   gkn = Jkn'*rkn;
   
   s=xkn-xk;
   t = gk;
   g = gkn;
   d = dk;
   y=g-t;
        
   zk=max((s'*y),-(s'*t));
     
   lambda2=zk*(((y'*g)-(s'*g))/((y'*s)*(g'*t)))-(y'*g)/(g'*t);

    
    
    if (lambda2 < 0) || (g'*t)==0
       lambda = 0;
    elseif lambda2 > min(1, 100*norm(s))
        lambda = min(1, 100*norm(s));
    else
        lambda = lambda2;
    end
    

    bhDC= (norm(g)^2)/zk;
    bhHL=(y'*g)/zk;
    bhHLplus=max(0,bhHL);
 


    v1=  bhHLplus;
    v2 = bhDC;       
     
    if (lambda>0)&&(lambda<1)
          beta=((1-lambda)*v1)+lambda*v2;
    elseif lambda>=1
          beta= bhDC;
    else
          beta= bhHLplus;
    end
    
    Beta=(1+beta*((g'*d)/(norm(g)^2)));
    
    dkn = -Beta*g + beta*d; 

    


     % updating the values of xc, gc, f's, Q & C
    dk = dkn;
    fkz = fkzn;
    xk = xkn;
    gk = gkn;
    iter = iter +1;  
    normg=norm(gk,inf);

end