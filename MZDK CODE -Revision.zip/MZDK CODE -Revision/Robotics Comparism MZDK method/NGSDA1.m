function xk = NGSDA1(rd, x0)

%This is the proposed MZDK method
%An improved Dai-Kou conjugate gradient methods
%with spectral search direction and applications
%by
%Nasiru Salihu1,2,3, Poom Kumam1∗, Lin Wang 3,4∗, Mahmoud M. Yahaya1


% initializations
xk = x0;
iter = 0;

rk = [cos(xk(1)) + cos(xk(1) + xk(2)) + cos(xk(1) + xk(2) + xk(3)); sin(xk(1)) + sin(xk(1) + xk(2)) + sin(xk(1) + xk(2) + xk(3))] - rd;
fkz = 1/2*norm(rk,2)^2;
% Initial Jacobian matrix
Jk = [-sin(xk(1))-sin(xk(1)+xk(2))-sin(xk(1)+xk(2)+xk(3)) -sin(xk(1)+xk(2))-sin(xk(1)+xk(2)+xk(3)) -sin(xk(1)+xk(2)+xk(3)); cos(xk(1))+cos(xk(1)+xk(2))+cos(xk(1)+xk(2)+xk(3)) cos(xk(1)+xk(2))+cos(xk(1)+xk(2)+xk(3)) cos(xk(1)+xk(2)+xk(3))];
% Gradient function gk = J'F
gk = Jk'*rk;
% Initiate b
%Initial Direction
dk = -gk;
normg = norm(gk, inf);
while (normg > 10^(-5)&&iter<=1000)          %( norm(fk) > 10^(-5)*sqrtn + 10^(-4)*norm(f0) )

% This while loop will find a suitable step (Strong Wolfe line search)        
   alpha = St_WolfeN2(xk, rd, gk, dk, fkz );
   xkn = xk + alpha*dk;
   rkn = [cos(xkn(1)) + cos(xkn(1) + xkn(2)) + cos(xkn(1) + xkn(2) + xkn(3)); sin(xkn(1)) + sin(xkn(1) + xkn(2)) + sin(xkn(1) + xkn(2) + xkn(3))] - rd;

   fkzn= 0.5*norm(rkn,2)^2;  % test_functions(xkn,op);  
   Jkn = [-sin(xkn(1))-sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2)+xkn(3)); cos(xkn(1))+cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2)+xkn(3))];
   gkn = Jkn'*rkn;
   
   s=xkn-xk;
   t = gk;
   g = gkn;
   d = dk;
   y=g-t;
    

    
    if  norm(g)>=1 
        r=1;
    else
        r=3;
    end
    

    hk=min((d'*y/norm(s)^2)*norm(t)^r,0); 
    zk=y+hk+norm(t)^r*s;
   
    
    %% computing the search direction  
    
    beta =(zk'*g)/(d'*zk)-min((zk'*g)/(d'*zk),((norm(zk)^2/(d'*zk))*((g'*d)/(d'*zk)))); 
    
    
    z= ((g'*s)/(g'*zk))*(((zk'*s)/(norm(s)^2))-((norm(zk)^2)/(zk'*s)));
      
    theta =max(1.001,1+z);  % this is thetak
   
    dkn = -g*theta + beta*d; 

    

    % updating the values of xc, gc, f's, Q & C
    dk = dkn;
    fkz = fkzn;
    xk = xkn;
    gk = gkn;
    iter = iter +1;  
    normg=norm(gk,inf);

end