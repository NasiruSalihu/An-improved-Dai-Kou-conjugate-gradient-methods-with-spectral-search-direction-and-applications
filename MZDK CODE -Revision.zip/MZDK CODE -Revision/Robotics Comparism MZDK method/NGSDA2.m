function xk = NGSDA2(rd, x0)

%This is SHCG2 method
%Two efficient spectral hybrid CG methods based on
%memoryless BFGS direction and Dai–Liao conjugacy condition
%by
%Pengjie Liua,b, Zihang Yuana, Yue Zhuoa and Hu Shaoa
%OPTIMIZATION METHODS & SOFTWARE
%https://doi.org/10.1080/10556788.2024.2364203


% initializations
xk = x0;
iter = 0;

rk = [cos(xk(1)) + cos(xk(1) + xk(2)) + cos(xk(1) + xk(2) + xk(3)); sin(xk(1)) + sin(xk(1) + xk(2)) + sin(xk(1) + xk(2) + xk(3))] - rd;
fkz = 1/2*norm(rk,2)^2;
% Initial Jacobian matrix
Jk = [-sin(xk(1))-sin(xk(1)+xk(2))-sin(xk(1)+xk(2)+xk(3)) -sin(xk(1)+xk(2))-sin(xk(1)+xk(2)+xk(3)) -sin(xk(1)+xk(2)+xk(3)); cos(xk(1))+cos(xk(1)+xk(2))+cos(xk(1)+xk(2)+xk(3)) cos(xk(1)+xk(2))+cos(xk(1)+xk(2)+xk(3)) cos(xk(1)+xk(2)+xk(3))];
% Gradient function gk = J'F
gk = Jk'*rk;
% Initiate b
%Initial Direction
dk = -gk;
normg = norm(gk, inf);
while (normg > 10^(-5)&&iter<=1000)          %( norm(fk) > 10^(-5)*sqrtn + 10^(-4)*norm(f0) )

% This while loop will find a suitable step (Strong Wolfe line search)        
   alpha = St_WolfeN2(xk, rd, gk, dk, fkz );
   xkn = xk + alpha*dk;
   rkn = [cos(xkn(1)) + cos(xkn(1) + xkn(2)) + cos(xkn(1) + xkn(2) + xkn(3)); sin(xkn(1)) + sin(xkn(1) + xkn(2)) + sin(xkn(1) + xkn(2) + xkn(3))] - rd;

   fkzn= 0.5*norm(rkn,2)^2;  % test_functions(xkn,op);  
   Jkn = [-sin(xkn(1))-sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2)+xkn(3)); cos(xkn(1))+cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2)+xkn(3))];
   gkn = Jkn'*rkn;
   
   t = gk;
   g = gkn;
   d = dk;

    y=g-t;
    d1=(g'*(g-t))/(d'*(g-t))-(2*((norm(y)^2)*g'*d)/((d'*(g-t))^2));
    d2=(-1/(norm(d)*min(0.1,norm(g)))); 
    Beta=max(d1,d2);

    dkn =-g+Beta*d;
    
     % updating the values of xc, gc, f's, Q & C
    dk = dkn;
    fkz = fkzn;
    xk = xkn;
    gk = gkn;
    iter = iter +1;  
    normg=norm(gk,inf);

end