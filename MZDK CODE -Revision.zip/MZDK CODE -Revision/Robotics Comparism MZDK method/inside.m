function in = inside(x, a, b)
in = 0;
if ~isreal(x)   
   return
end
if a <= b
   if x >= a & x <= b
      in = 1;
   end
else
   if x >= b & x <= a
      in = 1;
   end
end
