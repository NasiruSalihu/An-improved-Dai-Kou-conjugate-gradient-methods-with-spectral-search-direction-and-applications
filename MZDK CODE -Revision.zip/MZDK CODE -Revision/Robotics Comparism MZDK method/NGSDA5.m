function xk = NGSDA5(rd, x0)

%This HCG method  
%A Hybrid Conjugate Gradient Algorithm for Nonconvex
%Functions and Its Applications in Image Restoration Problems
%by
%Gong-Lin Yuan1 · Ying-Jie Zhou1 · Meng-Xiang Zhang1
%Journal of the Operations Research Society of China (2023) 11:759–781
%https://doi.org/10.1007/s40305-022-00424-6


% initializations
xk = x0;
iter = 0;

rk = [cos(xk(1)) + cos(xk(1) + xk(2)) + cos(xk(1) + xk(2) + xk(3)); sin(xk(1)) + sin(xk(1) + xk(2)) + sin(xk(1) + xk(2) + xk(3))] - rd;
fkz = 1/2*norm(rk,2)^2;
% Initial Jacobian matrix
Jk = [-sin(xk(1))-sin(xk(1)+xk(2))-sin(xk(1)+xk(2)+xk(3)) -sin(xk(1)+xk(2))-sin(xk(1)+xk(2)+xk(3)) -sin(xk(1)+xk(2)+xk(3)); cos(xk(1))+cos(xk(1)+xk(2))+cos(xk(1)+xk(2)+xk(3)) cos(xk(1)+xk(2))+cos(xk(1)+xk(2)+xk(3)) cos(xk(1)+xk(2)+xk(3))];
% Gradient function gk = J'F
gk = Jk'*rk;
% Initiate b
%Initial Direction
dk = -gk;
normg = norm(gk, inf);
while (normg > 10^(-5)&&iter<=1000)          %( norm(fk) > 10^(-5)*sqrtn + 10^(-4)*norm(f0) )

% This while loop will find a suitable step (Strong Wolfe line search)        
   alpha = St_WolfeN2(xk, rd, gk, dk, fkz );
   xkn = xk + alpha*dk;
   rkn = [cos(xkn(1)) + cos(xkn(1) + xkn(2)) + cos(xkn(1) + xkn(2) + xkn(3)); sin(xkn(1)) + sin(xkn(1) + xkn(2)) + sin(xkn(1) + xkn(2) + xkn(3))] - rd;

   fkzn= 0.5*norm(rkn,2)^2;  % test_functions(xkn,op);  
   Jkn = [-sin(xkn(1))-sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2))-sin(xkn(1)+xkn(2)+xkn(3)) -sin(xkn(1)+xkn(2)+xkn(3)); cos(xkn(1))+cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2))+cos(xkn(1)+xkn(2)+xkn(3)) cos(xkn(1)+xkn(2)+xkn(3))];
   gkn = Jkn'*rkn;
   
   s=xkn-xk;
   t = gk;
   g = gkn;
   d = dk;
   y=g-t;
        
   M=max((2*(fkz-fkzn)+s'*(g+t)), 0);
   y2=y+ (M*s/norm(s)^2);
   denum = max(0.001*norm(y2)*norm(d), norm(t)^2);
   betaMPRP= (g'*y2)/denum;

   denum2 = max(0.001*norm(g)*norm(d), norm(t)^2);
   betaMFR= (norm(g)^2)/denum2;
   
   skbar = s + (max(0, (-s'*y2)/norm(y2)^2)+1)*y2;
   delta = norm(y2)^2/(y2'*skbar);

   betaHCG = (1-delta)*betaMPRP +delta*betaMFR;

   dkn = -(1+betaHCG*(g'*d)/norm(g)^2)*g + betaHCG*d;
   


     % updating the values of xc, gc, f's, Q & C
    dk = dkn;
    fkz = fkzn;
    xk = xkn;
    gk = gkn;
    iter = iter +1;  
    normg=norm(gk,inf);

end